package njitfitclub;

public class Member {
	
	private int Mem_ID;
	private String firstName;
	private String lastName;
	private int aptNum;
	private String street;
	private String city;
	private String state;
	private int zip;
	private String regDate;
	
	private int EX_ID;
	private String ExName;
	
	public Member(int Mem_ID, String firstName, String lastName, int aptNum, String street, String city, String state, int zip, String regDate) {
		this.Mem_ID = Mem_ID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.aptNum = aptNum;
		this.street = street;
		this.state = state;
		this.zip = zip;
		this.regDate = regDate;
	}

	public Member(int Mem_ID, String firstName, String lastName, int aptNum, String street, String city, String state, int zip, String regDate, int EX_ID, String ExName) {
		this.Mem_ID = Mem_ID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.aptNum = aptNum;
		this.street = street;
		this.state = state;
		this.zip = zip;
		this.regDate = regDate;
		this.EX_ID = EX_ID;
		this.ExName = ExName;
	}

	
	public int getMem_ID() {
		return Mem_ID;
	}
	public void setMem_ID(int mem_ID) {
		Mem_ID = mem_ID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public int getEX_ID() {
		return EX_ID;
	}



	public void setEX_ID(int eX_ID) {
		EX_ID = eX_ID;
	}



	public String getExName() {
		return ExName;
	}



	public void setExName(String exName) {
		ExName = exName;
	}
	
	

}
