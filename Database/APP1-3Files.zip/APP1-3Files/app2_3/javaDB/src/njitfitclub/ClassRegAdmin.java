package njitfitclub;

public class ClassRegAdmin {

	private int class_id;
	public int getClass_id() {
		return class_id;
	}

	public void setClass_id(int class_id) {
		this.class_id = class_id;
	}

	public int getEx_id() {
		return ex_id;
		
	}

	public void setEx_id(int ex_id) {
		this.ex_id = ex_id;
	}

	public int getInstr_id() {
		return instr_id;
	}

	public void setInstr_id(int instr_id) {
		this.instr_id = instr_id;
	}

	public String getInstr_name() {
		return instr_name;
	}

	public void setInstr_name(String instr_name) {
		this.instr_name = instr_name;
	}

	public int getRmNum() {
		return rmNum;
	}

	public void setRmNum(int rmNum) {
		this.rmNum = rmNum;
	}

	public String getBldgName() {
		return bldgName;
	}

	public void setBldgName(String bldgName) {
		this.bldgName = bldgName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	private int ex_id;
	private int instr_id;
	private String instr_name;
	private int rmNum;
	private String bldgName;
	private String date;
	private String time;
	private String duration;
	private int capacity;

	public ClassRegAdmin(int class_id, int ex_id, int instr_id, String bldgName, int rmNum, String date, String time,
			String duration, int capacity) {
		this.class_id = class_id;
		this.ex_id = ex_id;
		this.instr_id = instr_id;
		this.bldgName = bldgName;
		this.rmNum = rmNum;
		this.date = date;
		this.time = time;
		this.duration = duration;
		this.capacity = capacity;
	}

}
