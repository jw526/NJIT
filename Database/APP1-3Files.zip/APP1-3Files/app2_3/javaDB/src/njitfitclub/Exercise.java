package njitfitclub;

public class Exercise {

	private int EX_ID;
	private String EX_NAME;
	private String DESCRIPTION;

	public Exercise(int EX_ID, String EX_NAME, String DESCRIPTION) {
		this.EX_ID = EX_ID;
		this.EX_NAME = EX_NAME;
		this.DESCRIPTION = DESCRIPTION;
	}
	
	public int getEX_ID() {
		return EX_ID;
	}

	public void setEX_ID(int eX_ID) {
		EX_ID = eX_ID;
	}

	public String getEX_NAME() {
		return EX_NAME;
	}

	public void setEX_NAME(String eX_NAME) {
		EX_NAME = eX_NAME;
	}

	public String getDESCRIPTION() {
		return DESCRIPTION;
	}

	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}

}
