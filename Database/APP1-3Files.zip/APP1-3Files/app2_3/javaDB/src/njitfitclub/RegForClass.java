package njitfitclub;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;

import javax.swing.JComboBox;

public class RegForClass extends JFrame implements ActionListener {
	Connect conn = new Connect();
	java.sql.Connection connect;

	private static final long serialVersionUID = -1858692165751812300L;

	private static int pos = 0;

	public static int getPos() {
		return pos;
	}

	public String name = LogIn.holdUname;
	private JComboBox cb;
	private JPanel contentPane;
	private JTextField CLASS_ID;
	private JTextField CLASS_NAME;
	private static RegForClass frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new RegForClass();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegForClass() {
		getContentPane().setBackground(new Color(175, 238, 238));
		setBounds(100, 100, 932, 593);
		System.out.println("jj  " + LogIn.holdUname);
		getMem();
		format();
		getMyClass();
		showClassReg();

	}

	public static int memId = 1;

	public String getMem() {
		System.out.println("l  " + memId);
		
		connect = conn.getConnection();
		String query = "SELECT M.MEM_ID FROM member M WHERE M.USERNAME = '" + name + "'";
		Statement st;
		ResultSet rs;

		String x = "";
		try {
			st = connect.createStatement();
			rs = st.executeQuery(query);
			while (rs.next()) {
				memId = rs.getInt("M.MEM_ID");
				x = Integer.toString(memId);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return x;
	}



	public void getMyClass() {
		String m = getMem();
		System.out.println("hh " + m);
		System.out.println("ll44  " + memId);
		connect = conn.getConnection();
		String query = "SELECT DISTINCT M.MEM_ID, ER.MEM_ID, ER.CLASS_ID, C.TIME, E.EX_ID, E.EX_NAME "
				+ "FROM class C, member M, exercises E, exercise_reg ER "
				+ "WHERE M.MEM_ID = ER.MEM_ID AND C.EX_ID = E.EX_ID AND C.CLASS_ID = ER.CLASS_ID "
				+ "AND M.MEM_ID =" + memId;
		Statement st;
		ResultSet rs;

		try {

			st = connect.createStatement();
			rs = st.executeQuery(query);

			while (rs.next()) {
				cb.addItem(rs.getString("E.EX_NAME") + " at " + rs.getString("C.TIME"));
			}
			rs = st.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "error");
		}
	}

	/**
	 * Display Data In JTable - Fill ArrayList With The Data
	 * 
	 */

	public void getClassInfo(int temp) {
		temp++;
		connect = conn.getConnection();
		System.out.println("temp is: " + temp);
		String query = "SELECT M.MEM_ID, M.FIRST_NAME, M.LAST_NAME, C.CLASS_ID,E.EX_ID, E.EX_NAME "
				+ "FROM class C, member M, exercises E, exercise_reg ER "
				+ "WHERE M.MEM_ID = ER.MEM_ID AND C.CLASS_ID = ER.CLASS_ID AND M.MEM_ID =" + memId;
		Statement st;
		ResultSet rs;

		try {

			st = connect.createStatement();
			rs = st.executeQuery(query);

			while (rs.next()) {
				// cb.addItem(rs.getString("E.EX_NAME"));
				// memId = rs.getInt("M.MEM_ID");
				cid.setText(rs.getString("C.CLASS_ID"));
				cname.setText(rs.getString("E.EX_NAME"));
			}
			rs = st.executeQuery(query);
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "error");
		}
	}

	public ArrayList<ClassReg> RegMe() {
		ArrayList<ClassReg> getClassList = new ArrayList<ClassReg>();
		connect = conn.getConnection();

		String query = "SELECT DISTINCT M.MEM_ID, C.CLASS_ID, E.EX_ID, E.EX_NAME, "
				+ "C.TIME, C.DURATION, C.DATE, C.TIME, C.DURATION, C.CAPACITY, "
				+ "I.INSTRUCTOR_NAME FROM class C, exercises E, instructor I, member M, exercise_reg ER "
				+ " WHERE C.EX_ID = E.EX_ID  AND I.INSTR_ID = C.INSTR_ID AND ER.MEM_ID = M.MEM_ID "
				+ "AND ER.CLASS_ID = E.EX_ID And M.MEM_ID= "+ memId;				
				//"SELECT C.CLASS_ID, E.EX_ID, E.EX_NAME, C.TIME, C.DURATION, C.DATE, C.TIME, C.DURATION, C.CAPACITY, I.INSTRUCTOR_NAME FROM class C, "
				//+ "exercises E, instructor I WHERE C.EX_ID = E.EX_ID  AND I.INSTR_ID = C.INSTR_ID;";

		Statement st;
		ResultSet rs;

		try {
			st = connect.createStatement();
			rs = st.executeQuery(query);
			ClassReg creg;
			while (rs.next()) {
				creg = new ClassReg(rs.getInt("C.CLASS_ID"), rs.getInt("E.EX_ID"), rs.getString("E.EX_NAME"),
						rs.getString("INSTRUCTOR_NAME"), rs.getString("DATE"), rs.getString("TIME"),
						rs.getString("DURATION"), rs.getInt("CAPACITY"));
				getClassList.add(creg);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return getClassList;

	}

	/**
	 * Display Data In JTable - Populate the JTable
	 * 
	 */

	public void showClassReg() {
		ArrayList<ClassReg> list = RegMe();
		DefaultTableModel model = (DefaultTableModel) table.getModel();

		model.setRowCount(0);// clearJTableContent
		Object[] row = new Object[4];
		for (int i = 0; i < list.size(); i++) {
			//row[0] = list.get(i).getClass_id();
			row[0] = list.get(i).getEx_name();
			row[1] = list.get(i).getTime();
			row[2] = list.get(i).getDuration();
			row[3] = list.get(i).getCapacity();

			for (Object rows : row) {
				System.out.println(rows);
			}
			model.addRow(row);
		}

	}

	public void showItem(int Index) {
		cid.setText(Integer.toString(RegMe().get(Index).getClass_id()));
		cname.setText(RegMe().get(Index).getEx_name());
	}

	/**
	 * Initial the Main Window & its components
	 */

	private JTable classReg;
	private JTable table;
	private JTextField cid;
	private JTextField cname;
	private JTextField tf;

	public void format() {
		JLabel lblUName = new JLabel("Hello  " + njitfitclub.LogIn.holdUname);
		lblUName.setBackground(new Color(240, 255, 240));
		lblUName.setFont(new Font("Tahoma", Font.PLAIN, 20));
		JScrollPane scrollPane = new JScrollPane();

		table = new JTable();
		scrollPane.setViewportView(table);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = table.getSelectedRow();
				showItem(index);
			}
		});
		table.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "CLASS_NAME", "TIME", "DURATION", "CAPACITY" }));

		JLabel lblClassIdName = new JLabel("CLASS ID");
		lblClassIdName.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JLabel lblClassName_1 = new JLabel("CLASS NAME");
		lblClassName_1.setFont(new Font("Tahoma", Font.PLAIN, 14));

		cid = new JTextField();
		cid.setColumns(10);

		cname = new JTextField();
		cname.setColumns(10);

		JButton reg = new JButton("REGISTER");
		reg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.out.println("yes");

				try {
					connect = conn.getConnection();

					String query = " insert into exercise_reg (MEM_ID, CLASS_ID)" + " values(?, ?)";

					PreparedStatement ps = connect.prepareStatement(query);
					int y = Integer.parseInt(cid.getText());
					System.out.println(y + " " + memId);
					ps.setInt(1, memId);
					ps.setInt(2, y);

					JOptionPane.showMessageDialog(null, "Registered!");

					ps.executeUpdate();
					getMyClass();
					showClassReg();
					
				} catch (SQLException ex) {

					JOptionPane.showMessageDialog(null, ex.getMessage());
				}

			}
		});

		JButton unReg = new JButton("UNREGISTER");
		unReg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!cid.getText().equals("")) {
					try {
						connect = conn.getConnection();

						String deleteQuery = "DELETE FROM exercise_reg WHERE MEM_ID = ? AND CLASS_ID = ?";
						PreparedStatement ps = connect.prepareStatement(deleteQuery);
						
						int id = memId;
						System.out.println(cid.getText());
						int id2 = Integer.parseInt(cid.getText());

						ps.setInt(1, id);
						ps.setInt(2, id2);

						ps.executeUpdate();
						JOptionPane.showMessageDialog(null, "Unregistered");
						cb.removeAll();
						showClassReg();

					} catch (SQLException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Not Unregistered -");
					}

				} else {
					JOptionPane.showMessageDialog(null, "Class Not Deleted : No CLASS ID Entered Or Visible");
				}
			}
		});

		JLabel lblMyClasses = new JLabel("MY CLASSES");
		lblMyClasses.setFont(new Font("Tahoma", Font.PLAIN, 16));

		cb = new JComboBox();

		tf = new JTextField();
		tf.setColumns(10);

		JButton btnBack = new JButton("BACK");
		btnBack.setActionCommand("BACK");
		btnBack.addActionListener(this);

		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout
						.createSequentialGroup().addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
										.addGap(20)
										.addGroup(groupLayout.createParallelGroup(Alignment.LEADING).addComponent(
												lblClassIdName, GroupLayout.PREFERRED_SIZE, 80,
												GroupLayout.PREFERRED_SIZE).addComponent(lblClassName_1)))
								.addComponent(btnBack))
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false).addGroup(groupLayout
								.createSequentialGroup().addGap(43)
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(cid, GroupLayout.PREFERRED_SIZE, 134, GroupLayout.PREFERRED_SIZE)
										.addGroup(groupLayout.createSequentialGroup()
												.addComponent(cname, GroupLayout.PREFERRED_SIZE, 134,
														GroupLayout.PREFERRED_SIZE)
												.addGap(224)
												.addComponent(lblMyClasses, GroupLayout.PREFERRED_SIZE, 118,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.UNRELATED).addComponent(cb,
														GroupLayout.PREFERRED_SIZE, 136, GroupLayout.PREFERRED_SIZE)))
								.addGap(165)).addGroup(
										groupLayout.createSequentialGroup().addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(lblUName, GroupLayout.PREFERRED_SIZE, 127,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE,
														Short.MAX_VALUE)
												.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 635,
														GroupLayout.PREFERRED_SIZE)
												.addGap(29))))
				.addGroup(groupLayout.createSequentialGroup().addGap(28)
						.addComponent(reg, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE).addGap(30)
						.addComponent(unReg, GroupLayout.DEFAULT_SIZE, 123, Short.MAX_VALUE).addGap(634))
				.addGroup(groupLayout.createSequentialGroup().addContainerGap(900, Short.MAX_VALUE)
						.addComponent(tf, GroupLayout.PREFERRED_SIZE, 12, GroupLayout.PREFERRED_SIZE).addGap(18)));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.LEADING).addGroup(groupLayout
				.createSequentialGroup()
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup().addGap(33).addComponent(lblUName,
								GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup().addContainerGap().addComponent(scrollPane,
								GroupLayout.PREFERRED_SIZE, 236, GroupLayout.PREFERRED_SIZE))
						.addComponent(btnBack))
				.addPreferredGap(ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addGroup(groupLayout.createSequentialGroup().addGap(130)
								.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
										.addComponent(cb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(lblMyClasses, GroupLayout.PREFERRED_SIZE, 49,
												GroupLayout.PREFERRED_SIZE)))
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false).addGroup(groupLayout
								.createSequentialGroup().addGap(51)
								.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
										.addComponent(lblClassIdName, GroupLayout.PREFERRED_SIZE, 30,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(cid, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(cname, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
								.addGroup(
										groupLayout.createSequentialGroup().addGap(123).addComponent(lblClassName_1))))
				.addPreferredGap(ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addComponent(unReg, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(reg, GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE))
				.addGap(47).addComponent(tf, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)));
		getContentPane().setLayout(groupLayout);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "BACK") {
			SelectPanelNonAdmin sp = new SelectPanelNonAdmin();
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			sp.setVisible(true);
			this.setVisible(false);
			sp.setLocationRelativeTo(null);
			this.dispose();
		}

	}
}