package njitfitclub;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class ExercisePanel extends JFrame implements ActionListener{
	Connect conn = new Connect();
	java.sql.Connection connect;

	private static final long serialVersionUID = -1858692165751812300L;

	private static int pos = 0;

	public static int getPos() {
		return pos;
	}

	private JPanel contentPane;
	private JTextField txtEX_ID;
	private JTextField txtDescription;
	private JTextField txtExName;
	private static ExercisePanel frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new ExercisePanel();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExercisePanel() {
		initComponents();
		showDataInTable();
	}

	/**
	 * Check Input Field
	 */
	public boolean checkInputs() {
		if (txtEX_ID.getText() == null || txtDescription.getText() == null) {
			return false;
		} else {
			try {
				txtDescription.getText();
				return true;
			} catch (Exception ex) {
				return false;
			}
		}

	}

	/**
	 * Display Data In JTable - Fill ArrayList With The Data
	 * 
	 */
	public ArrayList<Exercise> getExerciseList() {
		ArrayList<Exercise> exerciseList = new ArrayList<Exercise>();
		connect = conn.getConnection();
		String query = "SELECT * FROM exercises";

		Statement st;
		ResultSet rs;

		try {
			st = connect.createStatement();
			rs = st.executeQuery(query);
			Exercise exercise;
			while (rs.next()) {
				exercise = new Exercise(rs.getInt("EX_ID"), rs.getString("EX_NAME"), rs.getString("DESCRIPTION"));
				exerciseList.add(exercise);
				/////System.out.println(rs.getString(2)); 
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return exerciseList;

	}

	/**
	 * Display Data In JTable - Populate the JTable
	 * 
	 */

	public void showDataInTable() {
		ArrayList<Exercise> list = getExerciseList();
		DefaultTableModel model = (DefaultTableModel) dataTableShow.getModel();

		model.setRowCount(0);// clearJTableContent
		Object[] row = new Object[3];
		for (int i = 0; i < list.size(); i++) {
			row[0] = list.get(i).getEX_ID();
			row[1] = list.get(i).getEX_NAME();
			row[2] = list.get(i).getDESCRIPTION();
			model.addRow(row);
		}

	}

	public void showItem(int Index) {
		txtEX_ID.setText(Integer.toString(getExerciseList().get(Index).getEX_ID()));
		txtExName.setText(getExerciseList().get(Index).getEX_NAME());
		txtDescription.setText(getExerciseList().get(Index).getDESCRIPTION());
	}

	
	/**
	 * Initial the Main Window & its components
	 */

	private JTable dataTableShow;

	public void initComponents() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 932, 593);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Icon.class.getResource("/lib/largeowl.png")));
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 235));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel EX_IDLabel = new JLabel("EX_ID:");
		EX_IDLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		EX_IDLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));

		JLabel EX_NAMELabel = new JLabel("EX_NAME:");
		EX_NAMELabel.setHorizontalAlignment(SwingConstants.RIGHT);
		EX_NAMELabel.setFont(new Font("Tahoma", Font.PLAIN, 18));

		JLabel descrLabel = new JLabel("Description:");
		descrLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		descrLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));

		txtEX_ID = new JTextField();
		txtEX_ID.setDisabledTextColor(Color.BLUE);
		txtEX_ID.setEnabled(false);
		txtEX_ID.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtEX_ID.setColumns(10);

		txtExName = new JTextField();
		txtExName.setText("");
		txtExName.setSelectionStart(10);
		txtExName.setSelectionEnd(10);
		txtExName.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		txtExName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtExName.setColumns(10);

		txtDescription = new JTextField();
		txtDescription.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtDescription.setColumns(10);

		// JScrollPane scrollPane = new JScrollPane();

		JScrollPane exercisesTable = new JScrollPane();

		// BUTTONS
		// Insert Button and Action Handler
		JButton btnInsert = new JButton("INSERT");
		btnInsert.setBackground(Color.WHITE);
		btnInsert.setMargin(new Insets(2, 5, 2, 14));
		btnInsert.setHorizontalAlignment(SwingConstants.LEFT);
		btnInsert.setIconTextGap(15);

		btnInsert.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				System.out.println("yes");

				try {
					connect = conn.getConnection();

					String query = " insert into exercises (EX_NAME, DESCRIPTION)" + " values(?, ?)";
					PreparedStatement ps = connect.prepareStatement(query);
					ps.setString(1, txtExName.getText());
					ps.setString(2, txtDescription.getText());

					JOptionPane.showMessageDialog(null, "data entered");

					ps.executeUpdate();

					showDataInTable();

				} catch (SQLException ex) {

					JOptionPane.showMessageDialog(null, ex.getMessage());
				}

			}
		});

		btnInsert.setIcon(new ImageIcon(ExercisePanel.class.getResource("/icons/addButton32.png")));
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 14));

		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (checkInputs() && txtEX_ID.getText() != null) {
					String UpdateQuery = null;
					PreparedStatement ps = null;
					connect = conn.getConnection();

					// update without and image

					UpdateQuery = "UPDATE exercises SET EX_NAME = ?, DESCRIPTION = ?" + " WHERE EX_ID = ?";

					try {
						ps = connect.prepareStatement(UpdateQuery);

						ps.setString(1, txtExName.getText());
						ps.setString(2, txtDescription.getText());
						ps.setInt(3, Integer.parseInt(txtEX_ID.getText()));

						ps.executeUpdate();
						JOptionPane.showMessageDialog(null, "Exercise Updated");
						showDataInTable();

					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				}
			}
		});

		btnUpdate.setIcon(new ImageIcon(ExercisePanel.class.getResource("/icons/026-bar-chart32.png")));
		btnUpdate.setActionCommand("");
		btnUpdate.setMargin(new Insets(2, 1, 2, 14));
		btnUpdate.setIconTextGap(15);
		btnUpdate.setHorizontalAlignment(SwingConstants.LEFT);
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnUpdate.setBackground(Color.WHITE);

		JButton btnDelete = new JButton("DELETE");

		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (!txtEX_ID.getText().equals("")) {
					System.out.println(txtEX_ID.getText());
					try {
						connect = conn.getConnection();
						String deleteQuery = "DELETE FROM exercises WHERE EX_ID = ?";
						PreparedStatement ps = connect.prepareStatement(deleteQuery);
						int id = Integer.parseInt(txtEX_ID.getText());
						ps.setInt(1, id);
						ps.executeUpdate();
						JOptionPane.showMessageDialog(null, "Exercise Deleted");
						showDataInTable();

					} catch (SQLException e) {
						e.printStackTrace();
						JOptionPane.showMessageDialog(null, "Exercise Not Deleted -");
					}

				} else {
					JOptionPane.showMessageDialog(null, "Exercise Not Deleted : No E ID Entered Or Visible");
				}
			}
		});

		btnDelete.setIcon(new ImageIcon(ExercisePanel.class.getResource("/icons/deleteButton32.png")));
		btnDelete.setMargin(new Insets(2, 5, 2, 14));
		btnDelete.setIconTextGap(15);
		btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnDelete.setBackground(Color.WHITE);

		JButton btnFirst = new JButton("FIRST");
		btnFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Window window;
				ExercisePanel.pos = 0;
				showItem(ExercisePanel.pos);
				
			}
		});

		btnFirst.setIcon(new ImageIcon(ExercisePanel.class.getResource("/icons/061-push-pin32.png")));
		btnFirst.setMargin(new Insets(2, 1, 2, 14));
		btnFirst.setIconTextGap(15);
		btnFirst.setHorizontalAlignment(SwingConstants.LEFT);
		btnFirst.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnFirst.setBackground(Color.WHITE);

		JButton btnNext = new JButton("NEXT");
		btnNext.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				ExercisePanel.pos++;

				if (ExercisePanel.pos >= getExerciseList().size()) {
					ExercisePanel.pos = getExerciseList().size() - 1;
				}

				showItem(ExercisePanel.pos);
			}
		});

		btnNext.setIcon(new ImageIcon(ExercisePanel.class.getResource("/icons/007-right-arrow32.png")));
		btnNext.setMargin(new Insets(2, 1, 2, 14));
		btnNext.setIconTextGap(15);
		btnNext.setHorizontalAlignment(SwingConstants.LEFT);
		btnNext.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNext.setBackground(Color.WHITE);

		JButton btnPrevious = new JButton("PREVIOUS");


		btnPrevious.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ExercisePanel.pos = ExercisePanel.pos - 1;

				if (ExercisePanel.pos <= 0) {
					ExercisePanel.pos = 0;
				}

				showItem(ExercisePanel.pos);
			}

		});
	

		btnPrevious.setIcon(new ImageIcon(ExercisePanel.class.getResource("/icons/008-left-arrow32.png")));
		btnPrevious.setMargin(new Insets(2, 1, 2, 14));
		btnPrevious.setIconTextGap(15);
		btnPrevious.setHorizontalAlignment(SwingConstants.LEFT);
		btnPrevious.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnPrevious.setBackground(Color.WHITE);
		JButton btnLast = new JButton("LAST");

		btnLast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ExercisePanel.pos = getExerciseList().size() - 1;
				showItem(ExercisePanel.pos);
			}

		});
		btnLast.setIcon(new ImageIcon(ExercisePanel.class.getResource("/icons/043-push-pin32.png")));
		btnLast.setMargin(new Insets(2, 1, 2, 14));
		btnLast.setIconTextGap(15);
		btnLast.setHorizontalAlignment(SwingConstants.LEFT);
		btnLast.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnLast.setBackground(Color.WHITE);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setActionCommand("BACK");
		btnBack.addActionListener(this);

	
	

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
									.addGroup(Alignment.LEADING, gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addGroup(gl_contentPane.createSequentialGroup()
													.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
														.addComponent(txtDescription, GroupLayout.DEFAULT_SIZE, 373, Short.MAX_VALUE)
														.addGroup(gl_contentPane.createSequentialGroup()
															.addGap(10)
															.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
																.addComponent(EX_IDLabel, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
																.addComponent(EX_NAMELabel, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
																.addComponent(descrLabel, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE))
															.addPreferredGap(ComponentPlacement.UNRELATED)
															.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
																.addComponent(txtExName)
																.addComponent(txtEX_ID, GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
															.addGap(53)))
													.addGap(102))
												.addGroup(gl_contentPane.createSequentialGroup()
													.addComponent(btnBack)
													.addPreferredGap(ComponentPlacement.RELATED)))
											.addGap(421))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(btnInsert, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
											.addGap(26)
											.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED, 258, Short.MAX_VALUE)
											.addComponent(btnFirst, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
											.addContainerGap()))
									.addComponent(exercisesTable, GroupLayout.PREFERRED_SIZE, 421, GroupLayout.PREFERRED_SIZE))
								.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
									.addComponent(btnPrevious, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
									.addContainerGap()))
							.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
								.addComponent(btnNext, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
								.addContainerGap()))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnLast, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(65)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(EX_IDLabel, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
								.addComponent(txtEX_ID, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(EX_NAMELabel, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
								.addComponent(txtExName, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
							.addGap(11)
							.addComponent(descrLabel, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtDescription, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(exercisesTable, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE)
							.addComponent(btnBack)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(101)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(btnInsert)
								.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(7)
							.addComponent(btnNext, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnPrevious, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnFirst, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnLast, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(102, Short.MAX_VALUE))
		);

		dataTableShow = new JTable();
		dataTableShow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = dataTableShow.getSelectedRow();
				showItem(index);
			}
		});
		dataTableShow
				.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "EX_ID", "EX_NAME", "DECSRIPTION" }));
		dataTableShow.getColumnModel().getColumn(2).setPreferredWidth(150);
		exercisesTable.setViewportView(dataTableShow);

		contentPane.setLayout(gl_contentPane);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "BACK"){
			SelectPanel sp = new SelectPanel();
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			sp.setVisible(true);
			this.setVisible(false);
			sp.setLocationRelativeTo(null);
			this.dispose();
		}

	}
}