package njitfitclub;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class ChangePword extends JFrame implements ActionListener {
	/**
	 * ENTER USERNAME TO CHANGE PASSWORD
	 */
	private static final long serialVersionUID = 1L;
	private Connect conn = new Connect();
	private java.sql.Connection connect;

	private JPanel contentPane;
	private JTextField uName;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChangePword frame = new ChangePword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ChangePword() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Enter Username:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 96, 132, 36);
		contentPane.add(lblNewLabel);

		uName = new JTextField();
		uName.setBounds(126, 96, 171, 30);
		contentPane.add(uName);
		uName.setColumns(10);

		JButton btnEnter = new JButton("Enter");
		btnEnter.setActionCommand("LogMeIn");
		btnEnter.addActionListener(this);
		btnEnter.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));

		btnEnter.setBounds(316, 105, 67, 23);
		contentPane.add(btnEnter);
		
		JButton btnReturn = new JButton("RETURN");
		btnReturn.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnReturn.setBounds(10, 227, 89, 23);
		btnReturn.setActionCommand("RETURN");
		btnReturn.addActionListener(this);
		contentPane.add(btnReturn);

	}

	public void actionPerformed(ActionEvent e) {
		SelectPanelNonAdmin sp = new SelectPanelNonAdmin();
		if (e.getActionCommand() == "LogMeIn") {
			connect = conn.getConnection();
			PreparedStatement ps;
			ResultSet rs;
			try {
				ps = connect.prepareStatement("SELECT * FROM member WHERE USERNAME = ?");
				ps.setString(1, uName.getText());
				ChangePword cp = new ChangePword();
				rs = ps.executeQuery(); // execute the query

				if (rs.next()) {
					setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
					ChangeP2 p2 = new ChangeP2(uName.getText());
					
					p2.setVisible(true);
					cp.setVisible(false);
					p2.setLocationRelativeTo(null);
					this.dispose();
				} else {
					System.out.println("That UserName is not on file");
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand() == "RETURN") {

			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

			sp.setVisible(true);
			this.setVisible(false);
			sp.setLocationRelativeTo(null);
			this.dispose();

		}
	}
}
