package njitfitclub;

import java.awt.Toolkit;
import javax.swing.JFrame;

public class Icon extends JFrame{

	private static final long serialVersionUID = 542664715243468856L;

	// function to set icon
	public Icon() {

		setTitle("Icon");
		setBounds(200, 200, 300, 300);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Icon.class.getResource("/lib/largeowl.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
