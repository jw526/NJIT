package njitfitclub;

public class Room {
	
	private int RM_NUM;
	private String bldgName;
	private int capacity;

	public Room(int RM_NUM, String bldgName, int capacity) {
		this.RM_NUM = RM_NUM;
		this.bldgName = bldgName;
		this.capacity = capacity;
	}

	public int getRM_NUM() {
		return RM_NUM;
	}

	public void setRM_NUM(int rM_NUM) {
		RM_NUM = rM_NUM;
	}

	public String getBldgName() {
		return bldgName;
	}

	public void setBldgName(String bldgName) {
		this.bldgName = bldgName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

}
