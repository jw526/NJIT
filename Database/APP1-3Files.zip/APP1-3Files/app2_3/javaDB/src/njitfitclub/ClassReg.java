package njitfitclub;

public class ClassReg {
	
	private int class_id;
	private int ex_id;
	private String ex_name;
	private String instr_name;
	private String date;
	private String time;
	private String duration;
	private int capacity;
	
	public ClassReg(int class_id, int ex_id, String ex_name, String instr_name, String date, String time, String duration,
			int capacity) {
		this.class_id = class_id;
		this.ex_id = ex_id;
		this.setEx_name(ex_name);
		this.instr_name = instr_name;
		this.date = date;
		this.time = time;
		this.duration = duration;
		this.capacity = capacity;
	}

	public int getClass_id() {
		return class_id;
	}

	public void setClass_id(int class_id) {
		this.class_id = class_id;
	}

	public int getEx_id() {
		return ex_id;
	}

	public void setEx_id(int ex_id) {
		this.ex_id = ex_id;
	}

	public String getInstr_name() {
		return instr_name;
	}

	public void setInstr_name(String instr_name) {
		this.instr_name = instr_name;
	}


	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getEx_name() {
		return ex_name;
	}

	public void setEx_name(String ex_name2) {
		this.ex_name = ex_name2;
	}
	

}
