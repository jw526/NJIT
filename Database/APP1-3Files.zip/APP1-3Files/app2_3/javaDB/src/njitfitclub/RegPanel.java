package njitfitclub;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import com.toedter.calendar.JDateChooser;

import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.border.EtchedBorder;
import javax.swing.JComboBox;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class RegPanel extends JFrame implements ActionListener{
	Connect conn = new Connect();
	java.sql.Connection connect;

	static RegPanel frame;

	private JPanel contentPane;
	private JTextField ClassId_textField;
	private JTextField textField_EX_ID;
	private JTextField textField_RmNum;
	private JTextField textField_Time;
	private JTextField textField_Duration;
	private JTextField textField_Capacity;
	private JTextField textField_InstrID;
	private JDateChooser dateChooser = new JDateChooser();
	private JComboBox comboBox;
	private String addDate_1;
	private JTable table_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new RegPanel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void init() {
		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "CLASS_ID", "EX_ID", "INSTR_ID",
				"BLDG_NAME", "RM_NUM", "DATE", "TIME", "DURATION", "CAPACITY" }));

		connect = conn.getConnection();
		
		displayQData();

	}


	/**
	 * Display Data In JTable STEP 1 - Fill ArrayList With The Data
	 * 
	 */
	;


	public ArrayList<ClassRegAdmin> getRegList() {

		ArrayList<ClassRegAdmin> regList = new ArrayList<ClassRegAdmin>();
		connect = conn.getConnection();
		String query = "SELECT * FROM class";

		Statement st;
		ResultSet rs;

		try {
			st = connect.createStatement();
			rs = st.executeQuery(query);
			ClassRegAdmin classReg;
			comboBox = new JComboBox();
			while (rs.next()) {
				System.out.println(rs.getInt("CLASS_ID"));
				System.out.println(rs.getString("DATE"));
				classReg = new ClassRegAdmin(rs.getInt("CLASS_ID"), rs.getInt("EX_ID"), rs.getInt("INSTR_ID"),
						rs.getString("BLDG_NAME"), rs.getInt("RM_NUM"), rs.getString("DATE"), rs.getString("TIME"),
						rs.getString("DURATION"), rs.getInt("CAPACITY"));
				regList.add(classReg);
				comboBox.addItem(rs.getString("BLDG_NAME") + ", room " + rs.getInt("RM_NUM"));
			}

			// rs = st.executeQuery(query);

		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "error");
		}

		return regList;

	}

	/**
	 * Display Data In JTable STEP 2 - Populate the JTable
	 * 
	 */

	public void displayQData() {
		System.out.println(getRegList());
		ArrayList<ClassRegAdmin> list = getRegList();
		DefaultTableModel model = (DefaultTableModel) table_2.getModel();

		model.setRowCount(0);// clearJTableContent
		Object[] row = new Object[9];
		for (int i = 0; i < list.size(); i++) {

			row[0] = list.get(i).getClass_id();
			row[1] = list.get(i).getEx_id();
			row[2] = list.get(i).getInstr_id();
			row[3] = list.get(i).getBldgName();
			row[4] = list.get(i).getRmNum();
			row[5] = list.get(i).getDate();
			row[6] = list.get(i).getTime();
			row[7] = list.get(i).getDuration();
			row[8] = list.get(i).getCapacity();

			for (Object rows : row) {
				System.out.println(rows);
			}
			model.addRow(row);
		}
	}

	public void showItem(int Index) {
		ClassId_textField.setText(Integer.toString(getRegList().get(Index).getClass_id()));
		textField_EX_ID.setText(Integer.toString(getRegList().get(Index).getEx_id()));
		textField_InstrID.setText(Integer.toString(getRegList().get(Index).getInstr_id()));
		txtBldg.setText(getRegList().get(Index).getBldgName());
		textField_RmNum.setText(Integer.toString(getRegList().get(Index).getRmNum()));
		try {
			Date addDate = null;
			addDate = new SimpleDateFormat("YYYY-MM-dd").parse((String) getRegList().get(Index).getDate());
			dateChooser.setDate(addDate);

		} catch (ParseException e) {
			e.printStackTrace();
		}
		textField_Time.setText(getRegList().get(Index).getTime());
		textField_Duration.setText(getRegList().get(Index).getDuration());
		textField_Capacity.setText(Integer.toString(getRegList().get(Index).getCapacity()));

	}
	

	public void getExInfo(int temp) {
		temp++;
		connect = conn.getConnection();
		System.out.println("temp is: " + temp);
		String query1 = "SELECT E.EX_NAME, I.INSTRUCTOR_NAME, E.DESCRIPTION FROM exercises E, instructor I, class C  "
				+ "WHERE E.EX_ID = C.EX_ID AND C.INSTR_ID = I.INSTR_ID " + "AND E.EX_ID = " + temp;
		System.out.println(query1);
		Statement st;
		ResultSet rs;

		try {

			st = connect.createStatement();
			rs = st.executeQuery(query1);

			while (rs.next()) {
				txtClassName.setText(rs.getString("E.EX_NAME"));
				txtInsName.setText(rs.getString("I.INSTRUCTOR_NAME"));
				txtDesc.setText(rs.getString("E.DESCRIPTION"));

			}

			// Connection con = getConn();
			// String deleteQuery = "DELETE FROM class WHERE CLASS_ID = ?";
			// PreparedStatement ps = con.prepareStatement(deleteQuery);

			rs = st.executeQuery(query1);
		} catch (SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "error");
		}
	}

	/**
	 * Create the frame.
	 */
	static int pos = 0;
	private JTextField txtClassName;
	private JTextField txtInsName;
	private JTextField txtDesc;
	private JTextField txtBldg;

	public RegPanel() {
		// connect to the database
		init();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 667);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 235));
		contentPane.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblClass_ID = new JLabel("Class_ID");
		lblClass_ID.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblClass_ID.setFocusTraversalPolicyProvider(true);

		JLabel lblClassName = new JLabel("EXercise ID");
		lblClassName.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblClassName.setFocusTraversalPolicyProvider(true);

		JLabel lblInstrid = new JLabel("Instr_ID");
		lblInstrid.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblInstrid.setFocusTraversalPolicyProvider(true);

		JLabel lblRmnum = new JLabel("Rm_Num");
		lblRmnum.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblRmnum.setFocusTraversalPolicyProvider(true);

		JLabel lblDate = new JLabel("Date");
		lblDate.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDate.setFocusTraversalPolicyProvider(true);

		JLabel lblTime = new JLabel("Time");
		lblTime.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblTime.setFocusTraversalPolicyProvider(true);

		JLabel lblDuration = new JLabel("Duration");
		lblDuration.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblDuration.setFocusTraversalPolicyProvider(true);

		JLabel lblCapacity = new JLabel("Capacity");
		lblCapacity.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblCapacity.setFocusTraversalPolicyProvider(true);

		ClassId_textField = new JTextField();
		ClassId_textField.setColumns(10);

		textField_EX_ID = new JTextField();
		textField_EX_ID.setColumns(10);

		textField_InstrID = new JTextField();
		textField_InstrID.setColumns(10);

		textField_RmNum = new JTextField();
		textField_RmNum.setColumns(10);

		textField_Time = new JTextField();
		textField_Time.setColumns(10);

		textField_Duration = new JTextField();
		textField_Duration.setColumns(10);

		textField_Capacity = new JTextField();
		textField_Capacity.setColumns(10);

		/*
		 * INSERT INTO THE DATABASE
		 */
		JButton btnInsert = new JButton("INSERT");
		btnInsert.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					connect = conn.getConnection();

					String query = " INSERT INTO class (CLASS_ID, EX_ID, INSTR_ID, RM_NUM, DATE, TIME, DURATION,  CAPACITY)"
							+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
					// String query = " INSERT INTO class (INSTR_ID, RM_NUM,
					// DATE, TIME, DURATION, CAPACITY)"
					// + " VALUES( ?, ?, ?, ?, ?, ?)";
					PreparedStatement ps = connect.prepareStatement(query);
					ps.setString(1, ClassId_textField.getText());
					ps.setString(2, textField_EX_ID.getText()); // change the
																// classname to
																// ex_id and
																// (for class
																// name just do
																// a join in
																// JDBC)
					ps.setString(3, textField_InstrID.getText());
					ps.setString(4, textField_RmNum.getText());
					SimpleDateFormat datePattern = new SimpleDateFormat("YYYY-MM-dd");
					addDate_1 = datePattern.format(dateChooser.getDate());
					ps.setString(5, addDate_1);
					ps.setString(6, textField_Time.getText());
					ps.setString(7, textField_Duration.getText());
					ps.setString(8, textField_Capacity.getText());

					JOptionPane.showMessageDialog(null, "data entered");

					ps.executeUpdate();

					displayQData();

				} catch (SQLException ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage());
				}
			}
		});

		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					connect = conn.getConnection();

					String query = " UPDATE class SET INSTR_ID=?, RM_NUM=?, DATE=?, TIME=?, DURATION=?,  CAPACITY=?"
							+ " WHERE CLASS_ID=? AND EX_ID = ?";
					PreparedStatement ps = connect.prepareStatement(query);

					ps.setString(1, textField_InstrID.getText());
					ps.setString(2, textField_RmNum.getText());
					SimpleDateFormat datePattern = new SimpleDateFormat("YYYY-MM-dd");
					String addDate = datePattern.format(dateChooser.getDate());
					ps.setString(3, addDate);
					ps.setString(4, textField_Time.getText());
					ps.setString(5, textField_Duration.getText());
					ps.setString(6, textField_Capacity.getText());

					ps.setString(7, ClassId_textField.getText());
					ps.setString(8, textField_EX_ID.getText());

					JOptionPane.showMessageDialog(null, "data entered");

					ps.executeUpdate();

					displayQData();

				} catch (SQLException ex) {
					JOptionPane.showMessageDialog(null, ex.getMessage());
				}
			}
		});

		JButton btnDelete = new JButton("DELETE");
		btnDelete.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!ClassId_textField.getText().equals("")) {
					System.out.println(ClassId_textField.getText());
					try {
						connect = conn.getConnection();
						String deleteQuery = "DELETE FROM class WHERE CLASS_ID = ? AND EX_ID = ? AND RM_NUM = ? AND INSTR_ID=?";
						PreparedStatement ps = connect.prepareStatement(deleteQuery);
						int id = Integer.parseInt(ClassId_textField.getText());
						int id1 = Integer.parseInt(textField_EX_ID.getText());
						int id2 = Integer.parseInt(textField_InstrID.getText());
						int id3 = Integer.parseInt(textField_RmNum.getText());
						ps.setInt(1, id);
						ps.setInt(2, id1);
						ps.setInt(3, id2);
						ps.setInt(4, id3);
						ps.executeUpdate();
						JOptionPane.showMessageDialog(null, "Exercise Deleted");
						displayQData();

					} catch (SQLException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Exercise Not Deleted -");
					}

				} else {
					JOptionPane.showMessageDialog(null, "Exercise Not Deleted : No CLASS ID Entered Or Visible");
				}
			}
		});

		JButton btnFirst = new JButton("FIRST");
		btnFirst.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegPanel.pos = 0;
				showItem(RegPanel.pos);
				getExInfo(RegPanel.pos);
			}
		});

		JButton btnPrevious = new JButton("PREVIOUS");
		btnPrevious.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnPrevious.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegPanel.pos = RegPanel.pos - 1;

				if (RegPanel.pos == 0) {
					RegPanel.pos = 0;
				}

				showItem(RegPanel.pos);
				getExInfo(RegPanel.pos);
			}
		});

		JButton btnNext = new JButton("NEXT");
		btnNext.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegPanel.pos++;

				if (RegPanel.pos >= getRegList().size()) {
					RegPanel.pos = getRegList().size() - 1;
				}

				showItem(RegPanel.pos);
				getExInfo(RegPanel.pos);
			}
		});

		JButton btnLast = new JButton("LAST");
		btnLast.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnLast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RegPanel.pos = getRegList().size() - 1;
				showItem(RegPanel.pos);
				getExInfo(RegPanel.pos);
			}
		});

		JButton btnBack = new JButton("BackToMain");
		btnBack.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		btnBack.setActionCommand("BACK");
		btnBack.addActionListener(this);
	

		/*
		 * THE FOLLOWING RELATES TO THE FORMAT AND POSITION ONLY CODE GENERATED
		 * BY WINDOWBUILDER
		 */

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(173, 216, 230));
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = table_2.getSelectedRow();
				System.out.println("index is: " + index);
				showItem(index);

				getExInfo(index);
			}
		});

		JLabel lblClass = new JLabel("CLASS:");
		lblClass.setHorizontalAlignment(SwingConstants.RIGHT);
		lblClass.setFont(new Font("Tahoma", Font.BOLD, 14));

		txtClassName = new JTextField();
		txtClassName.setColumns(10);

		txtInsName = new JTextField();
		txtInsName.setColumns(10);

		JLabel lblInstructor = new JLabel("INSTRUCTOR:");
		lblInstructor.setHorizontalAlignment(SwingConstants.CENTER);
		lblInstructor.setFont(new Font("Tahoma", Font.BOLD, 14));

		txtDesc = new JTextField();
		txtDesc.setColumns(10);

		txtBldg = new JTextField();
		txtBldg.setColumns(10);

		JLabel lblBuilding = new JLabel("Building");
		lblBuilding.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblBuilding.setFocusTraversalPolicyProvider(true);

		JLabel lblrm = new JLabel("List of bldg and rooms");

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addComponent(btnBack)
								.addContainerGap(783, Short.MAX_VALUE))
						.addGroup(
								gl_contentPane.createSequentialGroup().addGap(47).addGroup(gl_contentPane
										.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
												.createSequentialGroup().addGroup(
														gl_contentPane.createParallelGroup(Alignment.LEADING)
																.addComponent(lblClassName, GroupLayout.PREFERRED_SIZE,
																		93, GroupLayout.PREFERRED_SIZE)
																.addComponent(lblInstrid, GroupLayout.PREFERRED_SIZE,
																		64, GroupLayout.PREFERRED_SIZE)
																.addComponent(lblClass_ID, GroupLayout.PREFERRED_SIZE,
																		64, GroupLayout.PREFERRED_SIZE)
																.addComponent(lblRmnum, GroupLayout.PREFERRED_SIZE, 80,
																		GroupLayout.PREFERRED_SIZE)
																.addComponent(lblCapacity, GroupLayout.PREFERRED_SIZE,
																		64, GroupLayout.PREFERRED_SIZE)
																.addComponent(lblDuration, GroupLayout.PREFERRED_SIZE,
																		64, GroupLayout.PREFERRED_SIZE)
																.addComponent(lblTime, GroupLayout.PREFERRED_SIZE,
																		64, GroupLayout.PREFERRED_SIZE)
																.addComponent(lblDate,
																		GroupLayout.PREFERRED_SIZE, 64,
																		GroupLayout.PREFERRED_SIZE)
																.addComponent(lblBuilding, GroupLayout.PREFERRED_SIZE,
																		64, GroupLayout.PREFERRED_SIZE))
												.addGap(18)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
														.addGroup(gl_contentPane.createSequentialGroup()
																.addComponent(textField_Capacity,
																		GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
																.addPreferredGap(ComponentPlacement.RELATED))
														.addGroup(gl_contentPane.createSequentialGroup()
																.addComponent(txtBldg, GroupLayout.PREFERRED_SIZE, 122,
																		GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(ComponentPlacement.RELATED))
														.addGroup(gl_contentPane.createSequentialGroup()
																.addComponent(dateChooser, GroupLayout.DEFAULT_SIZE,
																		122, Short.MAX_VALUE)
																.addPreferredGap(ComponentPlacement.RELATED))
														.addGroup(gl_contentPane.createSequentialGroup()
																.addComponent(textField_Time, GroupLayout.DEFAULT_SIZE,
																		122, Short.MAX_VALUE)
																.addPreferredGap(ComponentPlacement.RELATED))
														.addGroup(gl_contentPane.createSequentialGroup()
																.addComponent(textField_Duration,
																		GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
																.addPreferredGap(ComponentPlacement.RELATED))
														.addComponent(textField_RmNum, GroupLayout.DEFAULT_SIZE, 122,
																Short.MAX_VALUE)
														.addComponent(textField_InstrID, GroupLayout.DEFAULT_SIZE, 122,
																Short.MAX_VALUE)
														.addComponent(textField_EX_ID, GroupLayout.DEFAULT_SIZE, 122,
																Short.MAX_VALUE)
														.addGroup(gl_contentPane.createSequentialGroup()
																.addComponent(ClassId_textField,
																		GroupLayout.PREFERRED_SIZE, 122,
																		GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(ComponentPlacement.RELATED)))
												.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
														.addGroup(gl_contentPane.createSequentialGroup().addGap(105)
																.addComponent(btnFirst, GroupLayout.PREFERRED_SIZE, 77,
																		GroupLayout.PREFERRED_SIZE)
																.addGroup(gl_contentPane
																		.createParallelGroup(Alignment.LEADING)
																		.addGroup(gl_contentPane.createSequentialGroup()
																				.addGap(86)
																				.addComponent(btnPrevious,
																						GroupLayout.DEFAULT_SIZE, 56,
																						Short.MAX_VALUE)
																				.addGap(53)
																				.addComponent(btnNext,
																						GroupLayout.PREFERRED_SIZE, 43,
																						GroupLayout.PREFERRED_SIZE)
																				.addGap(39)
																				.addComponent(btnLast,
																						GroupLayout.PREFERRED_SIZE, 48,
																						GroupLayout.PREFERRED_SIZE)
																				.addGap(61))
																		.addGroup(gl_contentPane.createSequentialGroup()
																				.addPreferredGap(
																						ComponentPlacement.RELATED)
																				.addGroup(gl_contentPane
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(txtDesc, 278, 278,
																								278)
																						.addGroup(gl_contentPane
																								.createSequentialGroup()
																								.addComponent(
																										txtClassName,
																										GroupLayout.PREFERRED_SIZE,
																										105,
																										GroupLayout.PREFERRED_SIZE)
																								.addPreferredGap(
																										ComponentPlacement.RELATED)
																								.addComponent(
																										txtInsName,
																										GroupLayout.PREFERRED_SIZE,
																										167,
																										GroupLayout.PREFERRED_SIZE)))
																				.addGap(102)))
																.addGap(52))
														.addGroup(gl_contentPane.createSequentialGroup().addGap(198)
																.addComponent(lblClass, GroupLayout.PREFERRED_SIZE, 67,
																		GroupLayout.PREFERRED_SIZE)
																.addGap(53).addComponent(lblInstructor,
																		GroupLayout.PREFERRED_SIZE, 133,
																		GroupLayout.PREFERRED_SIZE))
														.addGroup(gl_contentPane.createSequentialGroup().addGap(87)
																.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE,
																		480, GroupLayout.PREFERRED_SIZE))))
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 80,
														GroupLayout.PREFERRED_SIZE)
												.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 81,
														GroupLayout.PREFERRED_SIZE)
												.addComponent(btnInsert, GroupLayout.PREFERRED_SIZE, 49,
														GroupLayout.PREFERRED_SIZE)))
										.addContainerGap())
						.addGroup(gl_contentPane.createSequentialGroup().addGap(631)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblrm, GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
										.addGroup(gl_contentPane.createSequentialGroup()
												.addComponent(comboBox, 0, 196, Short.MAX_VALUE).addGap(78)))));
		gl_contentPane
				.setVerticalGroup(
						gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(
										gl_contentPane
												.createSequentialGroup().addGroup(gl_contentPane
														.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
																.createSequentialGroup().addComponent(btnBack)
																.addGap(22)
																.addGroup(gl_contentPane
																		.createParallelGroup(Alignment.BASELINE)
																		.addComponent(lblClass_ID,
																				GroupLayout.PREFERRED_SIZE, 24,
																				GroupLayout.PREFERRED_SIZE)
																		.addComponent(ClassId_textField,
																				GroupLayout.PREFERRED_SIZE,
																				24, GroupLayout.PREFERRED_SIZE))
																.addGap(18)
																.addGroup(gl_contentPane
																		.createParallelGroup(Alignment.TRAILING)
																		.addGroup(gl_contentPane.createSequentialGroup()
																				.addGroup(gl_contentPane
																						.createParallelGroup(
																								Alignment.LEADING)
																						.addComponent(lblInstructor,
																								GroupLayout.PREFERRED_SIZE,
																								22,
																								GroupLayout.PREFERRED_SIZE)
																						.addComponent(lblClass,
																								GroupLayout.PREFERRED_SIZE,
																								22,
																								GroupLayout.PREFERRED_SIZE))
																				.addPreferredGap(
																						ComponentPlacement.RELATED))
																		.addGroup(gl_contentPane.createSequentialGroup()
																				.addGroup(gl_contentPane
																						.createParallelGroup(
																								Alignment.TRAILING)
																						.addGroup(gl_contentPane
																								.createSequentialGroup()
																								.addComponent(
																										textField_EX_ID,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(
																										textField_InstrID,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(
																										textField_RmNum,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(txtBldg,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(
																										dateChooser,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE))
																						.addGroup(gl_contentPane
																								.createSequentialGroup()
																								.addComponent(
																										lblClassName,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(
																										lblInstrid,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(lblRmnum,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(
																										lblBuilding,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)
																								.addGap(18)
																								.addComponent(lblDate,
																										GroupLayout.PREFERRED_SIZE,
																										24,
																										GroupLayout.PREFERRED_SIZE)))
																				.addGap(18)
																				.addGroup(gl_contentPane
																						.createParallelGroup(
																								Alignment.BASELINE)
																						.addComponent(textField_Time,
																								GroupLayout.PREFERRED_SIZE,
																								24,
																								GroupLayout.PREFERRED_SIZE)
																						.addComponent(lblTime,
																								GroupLayout.PREFERRED_SIZE,
																								24,
																								GroupLayout.PREFERRED_SIZE))
																				.addGap(18)))
																.addGroup(gl_contentPane
																		.createParallelGroup(Alignment.BASELINE)
																		.addComponent(txtClassName,
																				GroupLayout.PREFERRED_SIZE, 22,
																				GroupLayout.PREFERRED_SIZE)
																		.addComponent(txtInsName,
																				GroupLayout.PREFERRED_SIZE, 22,
																				GroupLayout.PREFERRED_SIZE)
																		.addComponent(textField_Duration,
																				GroupLayout.PREFERRED_SIZE, 24,
																				GroupLayout.PREFERRED_SIZE)
																		.addComponent(lblDuration,
																				GroupLayout.PREFERRED_SIZE, 24,
																				GroupLayout.PREFERRED_SIZE)))
														.addGroup(gl_contentPane.createSequentialGroup().addGap(21)
																.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE,
																		210, GroupLayout.PREFERRED_SIZE)
																.addGap(18)
																.addGroup(gl_contentPane
																		.createParallelGroup(Alignment.BASELINE)
																		.addComponent(btnPrevious).addComponent(btnLast)
																		.addComponent(btnNext)
																		.addComponent(btnFirst))))
												.addGap(18)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
														.addGroup(gl_contentPane.createSequentialGroup()
																.addComponent(txtDesc, GroupLayout.PREFERRED_SIZE, 49,
																		GroupLayout.PREFERRED_SIZE)
																.addGap(28).addComponent(btnInsert).addGap(18)
																.addComponent(btnDelete).addGap(18)
																.addComponent(btnUpdate))
														.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
																.addComponent(textField_Capacity,
																		GroupLayout.PREFERRED_SIZE, 24,
																		GroupLayout.PREFERRED_SIZE)
																.addComponent(lblCapacity, GroupLayout.PREFERRED_SIZE,
																		24, GroupLayout.PREFERRED_SIZE)))
												.addGap(4).addComponent(lblrm)
												.addPreferredGap(ComponentPlacement.UNRELATED)
												.addComponent(comboBox, GroupLayout.PREFERRED_SIZE,
														GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
												.addGap(51)));
		dateChooser.setDateFormatString("YYYY-MM-dd");
		scrollPane.setViewportView(table_2);
		contentPane.setLayout(gl_contentPane);

	}

	/**
	 * Check Input Field
	 */

	public boolean check() {
		if (ClassId_textField.getText() == null || addDate_1 == null) {
			return false;
		} else {
			try {
				return true;
			} catch (Exception ex) {
				return false;
			}
		}

	}

	public static int getPos() {
		return pos;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "BACK"){
			SelectPanel sp = new SelectPanel();
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			sp.setVisible(true);
			this.setVisible(false);
			sp.setLocationRelativeTo(null);
			this.dispose();
		}

	}
}
