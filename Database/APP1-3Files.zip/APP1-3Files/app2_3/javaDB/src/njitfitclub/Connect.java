package njitfitclub;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Connect {
	String db = "INSERT P-WORD";

	Connect(){
		java.sql.Connection connect = null;
		try {
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/njitfitclub2?autoReconnect=true&useSSL=false", "root", db);
			//return connect;
		} catch (SQLException ex) {
			Logger.getLogger(ExercisePanel.class.getName()).log(Level.SEVERE, null, ex);
			//return null;
		}
	}
	
	public java.sql.Connection getConnection(){
		java.sql.Connection connect = null;
		try {
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/njitfitclub2?autoReconnect=true&useSSL=false", "root", db);
			return connect;
		} catch (SQLException ex) {
			Logger.getLogger(ExercisePanel.class.getName()).log(Level.SEVERE, null, ex);
			return null;
		}
		
	}

}
