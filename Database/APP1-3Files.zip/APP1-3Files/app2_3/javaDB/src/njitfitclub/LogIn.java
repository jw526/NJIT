package njitfitclub;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

public class LogIn extends JFrame implements ActionListener {
	Connect conn = new Connect();
	java.sql.Connection connect;
	static JTextField textField_username;
	private JPasswordField passwordField;
	JLabel label_u = new JLabel("*");
	JLabel label_p = new JLabel("*");

	public static LogIn frame;
	public static String holdUname;

	String LOGIN = "LOGIN";
	String CANCEL = "CANCEL";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new LogIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LogIn() {
		setLocationByPlatform(true);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		JPanel contentPane = new JPanel();
		contentPane.setBackground(new Color(175, 238, 238));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblNewLabel = new JLabel("Login Form");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 18));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBackground(Color.YELLOW);

		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 12));

		textField_username = new JTextField();
		textField_username.setFont(new Font("Tahoma", Font.PLAIN, 12));
		textField_username.setColumns(10);

		passwordField = new JPasswordField("");
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 12));

		// JLabel label_u = new JLabel("*");
		label_u.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_u.setForeground(new Color(255, 0, 51));
		label_u.setVisible(false);

		// JLabel label_p = new JLabel("*");
		label_p.setForeground(new Color(255, 0, 51));
		label_p.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_p.setVisible(false);

		JButton btn_login = new JButton("LogIn");
		btn_login.setActionCommand("LOGIN");
		btn_login.addActionListener(this);
		btn_login.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btn_login.setMargin(new Insets(2, 2, 2, 14));
		btn_login.setIconTextGap(8);
		btn_login.setIcon(new ImageIcon("C:\\Users\\arthu\\Documents\\Design\\ICONS\\log32b.png"));
		btn_login.setFont(new Font("Arial", Font.BOLD, 12));

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setActionCommand("CANCEL");
		btnCancel.addActionListener(this);
		btnCancel.setIcon(new ImageIcon("C:\\Users\\arthu\\Documents\\Design\\ICONS\\if_Delete.png"));
		btnCancel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCancel.setFont(new Font("Arial", Font.BOLD, 12));

		/*
		 * CONTENT CREATED BY WINDOW BUILDER
		 */

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
								.addGap(149).addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 111,
										GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup().addContainerGap()
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblPassword, GroupLayout.PREFERRED_SIZE, 79,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 79,
												GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(Alignment.TRAILING,
												gl_contentPane.createSequentialGroup()
														.addComponent(btnCancel, GroupLayout.PREFERRED_SIZE, 101,
																GroupLayout.PREFERRED_SIZE)
														.addGap(43)
														.addComponent(btn_login, GroupLayout.PREFERRED_SIZE, 106,
																GroupLayout.PREFERRED_SIZE)
														.addGap(40))
										.addGroup(gl_contentPane.createSequentialGroup()
												.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
														.addComponent(passwordField, Alignment.LEADING)
														.addComponent(textField_username, Alignment.LEADING,
																GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE))
												.addPreferredGap(ComponentPlacement.RELATED)))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(label_u, GroupLayout.PREFERRED_SIZE, 19,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(label_p, GroupLayout.PREFERRED_SIZE, 16,
												GroupLayout.PREFERRED_SIZE))))
				.addContainerGap()));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addContainerGap()
				.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE).addGap(18)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(label_u, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE).addGroup(gl_contentPane
								.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
								.addComponent(textField_username, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)))
				.addGap(36)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_p))
				.addGap(27)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancel, GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
						.addComponent(btn_login, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE))
				.addGap(19)));
		contentPane.setLayout(gl_contentPane);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		{

			if (e.getActionCommand() == LOGIN) {

				label_u.setVisible(false);
				label_p.setVisible(false);
				if (textField_username.getText().equals("")) {
					label_u.setVisible(true); // highlights missing user name
												// asterisk
				}
				if (String.valueOf(passwordField.getPassword()).equals("")) {
					label_p.setVisible(true); // Highlights missing password
												// asterisk
				} else {

					PreparedStatement ps;
					ResultSet rs; // create ps object
					try {

						connect = conn.getConnection();
						ps = connect.prepareStatement("SELECT * FROM member WHERE USERNAME = ? AND PASSWORD = ?");
						ps.setString(1, textField_username.getText());
						ps.setString(2, String.valueOf(passwordField.getPassword()));
						
						holdUname = textField_username.getText();
						System.out.println("login " + holdUname);

						rs = ps.executeQuery(); // execute the query

						if (rs.next()) {
							String adminPriv = rs.getString("ADMIN");
							if (adminPriv.equals("yes")) {
								setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
								SelectPanel sp = new SelectPanel();
								frame.setVisible(false);
								sp.setVisible(true);
								sp.setLocationRelativeTo(null);
								this.dispose();
							} else {
								setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
								SelectPanelNonAdmin sp = new SelectPanelNonAdmin();
								frame.setVisible(false);
								sp.setVisible(true);
								sp.setLocationRelativeTo(null);
								this.dispose();
							}

						}
					} catch (SQLException e1) {
						System.out.println("Bad username or password query");
						e1.printStackTrace();
					}

				}
			} else if (e.getActionCommand() == "CANCEL") {
				System.exit(0); 
			}
		}

	}

}