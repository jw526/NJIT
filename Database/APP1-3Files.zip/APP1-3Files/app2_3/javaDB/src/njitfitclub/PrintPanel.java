package njitfitclub;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;


public class PrintPanel extends JFrame implements ActionListener{
	Connect conn = new Connect();
	java.sql.Connection connect;

	private JPanel contentPane;
	private static PrintPanel frame;
	Image image;

	/**
	 * Create the frame.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new PrintPanel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	public PrintPanel() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 761, 424);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(new Color(255, 255, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		try {
			image = javax.imageio.ImageIO.read(new java.net.URL(getClass().getResource("Test.gif"), "Test.gif"));
		} catch (Exception e) {
			/* handled in paintComponent() */ }

		JButton btnManCl = new JButton("Current Class List");
		btnManCl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String output1 = "class.txt";
				PrintWriter data = null;
				
				ArrayList<ClassRegAdmin> cList = new ArrayList<ClassRegAdmin>();
				
				connect = conn.getConnection();
				String query = "SELECT C.CLASS_ID, C.EX_ID, C.INSTR_ID, C.BLDG_NAME, C.RM_NUM, C.DATE, C.TIME, C.DURATION, "
						+ "C.TIME, C.CAPACITY, E.EX_NAME FROM class C, exercises E WHERE C.EX_ID = E.EX_ID";
				Statement st;
				ResultSet rs;


				try {
					st = connect.createStatement();
					rs = st.executeQuery(query);
					
					ClassRegAdmin cr;
					System.out.println("The Current Classes Are:\n");
					
					data = new PrintWriter(new FileWriter(output1));
					data.println("The Current Classes Are:\n");
					
					while (rs.next()) {
						cr = new ClassRegAdmin(rs.getInt("CLASS_ID"), rs.getInt("EX_ID"), rs.getInt("INSTR_ID"),
								rs.getString("BLDG_NAME"), rs.getInt("RM_NUM"), rs.getString("DATE"), rs.getString("TIME"),
								rs.getString("DURATION"), rs.getInt("CAPACITY"));
						cList.add(cr);
						String temp = rs.getString("E.EX_NAME");

						System.out.printf("%-5d", cr.getClass_id());
						System.out.printf("%-20s", temp);
						System.out.printf("%-12s", cr.getDate());
						System.out.printf("%-10s", cr.getRmNum());
						System.out.printf("%-10s", cr.getDuration());
						System.out.printf("%-10s\n", cr.getTime());

						data.printf("%-5d", cr.getClass_id());
						data.printf("%-20s", temp);
						data.printf("%-12s", cr.getDate());
						data.printf("%-10s", cr.getRmNum());
						data.printf("%-10s", cr.getDuration());
						data.printf("%-10s\n", cr.getTime());
					}
				} catch (SQLException e4) {
					e4.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				System.out.println("\nData written to: " + output1 + "\n");
				data.close();
			}
		});

		btnManCl.setForeground(new Color(255, 255, 255));
		btnManCl.setBackground(new Color(51, 153, 255));
		btnManCl.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManCl.setBounds(415, 254, 141, 42);
		contentPane.setLayout(null);

		JLabel label = new JLabel("");
		label.setBounds(78, 74, 0, 0);
		contentPane.add(label);

		JLabel lblClickToPrint = new JLabel("CLICK TO PRINT:");
		lblClickToPrint.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblClickToPrint.setBounds(415, 21, 163, 42);
		contentPane.add(lblClickToPrint);

		JButton btnManEx = new JButton("Current Exercise List");
		btnManEx.setForeground(new Color(255, 255, 255));
		btnManEx.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String output = "exercises.txt";
				PrintWriter data = null;
				
				ArrayList<Exercise> eList = new ArrayList<Exercise>();
				//Connection con = getConnection();
				connect = conn.getConnection();
				String query = "SELECT * FROM exercises";
				Statement st;
				ResultSet rs;


				try {
					st = connect.createStatement();
					rs = st.executeQuery(query);
					Exercise ex;
					System.out.println("The Current Exercises Are:\n");
					data = new PrintWriter(new FileWriter(output));
					data.println("The Current Exercises Are:\n");
					while (rs.next()) {
						ex = new Exercise(rs.getInt("EX_ID"), rs.getString("EX_NAME"), rs.getString("DESCRIPTION"));
						eList.add(ex);
						
						System.out.printf("%-5d", ex.getEX_ID() );
						System.out.printf("%-30s", ex.getEX_NAME());
						System.out.printf("%-80s\n", ex.getDESCRIPTION());

						data.printf("%-5d", ex.getEX_ID() );
						data.printf("%-30s", ex.getEX_NAME());
						data.printf("%-80s\n", ex.getDESCRIPTION());
					}
				} catch (SQLException e4) {
					e4.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				System.out.println("\nData written to: " + output + "\n");
				data.close();
			}
		});

		JButton btnManInst = new JButton("Current Instructor List");
		btnManInst.setForeground(new Color(255, 255, 255));
		btnManInst.setBackground(new Color(51, 153, 255));
		btnManInst.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManInst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String output = "instructors.txt";
				PrintWriter data = null;
				
				ArrayList<Instructor> iList = new ArrayList<Instructor>();
				connect = conn.getConnection();
				//Connection con = getConnection();
				String query = "SELECT * FROM instructor";
				Statement st;
				ResultSet rs;

				try {
					st = connect.createStatement();
					rs = st.executeQuery(query);
					Instructor ins;
					System.out.println("The Current Instructors Are:\n");
					data = new PrintWriter(new FileWriter(output));
					data.println("The Current Instructors Are:\n");
					while (rs.next()) {
						ins = new Instructor(rs.getInt("INSTR_ID"), rs.getString("INSTRUCTOR_NAME"));
						iList.add(ins);

						System.out.printf("%-5d", ins.getINSTR_ID());
						System.out.printf("%-25s\n", ins.getINSTRUCTOR_NAME());

						data.printf("%-5d",ins.getINSTR_ID());
						data.printf("%-25s\n",ins.getINSTRUCTOR_NAME());
					}
				} catch (SQLException e4) {
					e4.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				System.out.println("\nData written to: " + output + "\n");
				data.close();
			}
		});
		btnManInst.setBounds(415, 102, 141, 43);
		contentPane.add(btnManInst);
		btnManEx.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManEx.setBackground(new Color(51, 153, 255));
		btnManEx.setBounds(415, 179, 141, 42);
		contentPane.add(btnManEx);
		contentPane.add(btnManCl);

		JLabel background = new JLabel(new ImageIcon(Icon.class.getResource("/lib/largeowl.png")));
		background.setBounds(138, 11, 226, 238);
		contentPane.add(background);
		
		JButton BackBtn = new JButton("Back");
		BackBtn.setBounds(10, 11, 89, 23);
		BackBtn.setActionCommand("BACK");
		BackBtn.addActionListener(this);
		contentPane.add(BackBtn);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "BACK"){
			SelectPanel sp = new SelectPanel();
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			sp.setVisible(true);
			this.setVisible(false);
			sp.setLocationRelativeTo(null);
			this.dispose();
		}

	}

}
