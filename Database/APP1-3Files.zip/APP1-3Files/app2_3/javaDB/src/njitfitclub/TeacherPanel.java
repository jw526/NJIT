package njitfitclub;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class TeacherPanel extends JFrame implements ActionListener{
	Connect conn = new Connect();
	java.sql.Connection connect;

	private static int pos = 0;

	public static int getPos() {
		return pos;
	}

	private JPanel contentPane;
	private JTextField txtInName;
	private static TeacherPanel frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new TeacherPanel();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TeacherPanel() {
		initComponents();
		displayData();
	}

	/**
	 * Display Data In JTable - Fill ArrayList With The Data
	 * 
	 */
	public ArrayList<Instructor> getInstrList() {
		ArrayList<Instructor> instrList = new ArrayList<Instructor>();
		connect = conn.getConnection();
		String query = "SELECT * FROM instructor";

		Statement st;
		ResultSet rs;

		try {
			st = connect.createStatement();
			rs = st.executeQuery(query);
			Instructor in;
			while (rs.next()) {
				in = new Instructor(rs.getInt("INSTR_ID"), rs.getString("INSTRUCTOR_NAME"));
				instrList.add(in);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return instrList;

	}

	/**
	 * Display Data In JTable - Populate the JTable
	 * 
	 */

	public void displayData() {
		ArrayList<Instructor> list = getInstrList();
		DefaultTableModel model = (DefaultTableModel) dataTableShow.getModel();

		model.setRowCount(0);// clearJTableContent
		Object[] row = new Object[2];
		for (int i = 0; i < list.size(); i++) {
			row[0] = list.get(i).getINSTR_ID();
			row[1] = list.get(i).getINSTRUCTOR_NAME();
			model.addRow(row);
		}

	}

	public void showItem(int Index) {
		txt_InID.setText(Integer.toString(getInstrList().get(Index).getINSTR_ID()));
		txtInName.setText(getInstrList().get(Index).getINSTRUCTOR_NAME());
	}

	/**
	 * Initial the Main Window & its components
	 */

	private JTable dataTableShow;
	private JTextField txt_InID;

	public void initComponents() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 932, 593);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Icon.class.getResource("/lib/largeowl.png")));
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 235));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel Instr_NAME = new JLabel("INSTR_NAME:");
		Instr_NAME.setHorizontalAlignment(SwingConstants.RIGHT);
		Instr_NAME.setFont(new Font("Tahoma", Font.PLAIN, 18));

		txtInName = new JTextField();
		txtInName.setText("");
		txtInName.setSelectionStart(10);
		txtInName.setSelectionEnd(10);
		txtInName.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		txtInName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtInName.setColumns(10);

		// JScrollPane scrollPane = new JScrollPane();

		JScrollPane instructorTable = new JScrollPane();

		// BUTTONS
		// Insert Button and Action Handler
		JButton btnInsert = new JButton("INSERT");
		btnInsert.setBackground(Color.WHITE);
		btnInsert.setMargin(new Insets(2, 5, 2, 14));
		btnInsert.setHorizontalAlignment(SwingConstants.LEFT);
		btnInsert.setIconTextGap(15);
		btnInsert.setIcon(new ImageIcon(TeacherPanel.class.getResource("/icons/addButton32.png")));
		btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnInsert.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				System.out.println("yes");

				try {
					connect = conn.getConnection();
					String query = " insert into instructor (INSTRUCTOR_NAME)" + " values(?)";
					PreparedStatement ps = connect.prepareStatement(query);
					ps.setString(1, txtInName.getText());
					JOptionPane.showMessageDialog(null, "data entered");
					ps.executeUpdate();
					displayData();
				} catch (SQLException ex) {

					JOptionPane.showMessageDialog(null, ex.getMessage());
				}

			}
		});



		JButton btnDelete = new JButton("DELETE");
		btnDelete.setIcon(new ImageIcon(TeacherPanel.class.getResource("/icons/deleteButton32.png")));
		btnDelete.setMargin(new Insets(2, 5, 2, 14));
		btnDelete.setIconTextGap(15);
		btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
		btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnDelete.setBackground(Color.WHITE);
		
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				if (!txt_InID.getText().equals("")) {
					System.out.println(txt_InID.getText());
					try {
						connect = conn.getConnection();
						String deleteQuery = "DELETE FROM instructor WHERE INSTR_ID = ?";
						PreparedStatement ps = connect.prepareStatement(deleteQuery);
						int id = Integer.parseInt(txt_InID.getText());
						ps.setInt(1, id);
						ps.executeUpdate();
						JOptionPane.showMessageDialog(null, "Instructor Deleted");
						displayData();

					} catch (SQLException e) {
						e.printStackTrace();
						JOptionPane.showMessageDialog(null, "Instructor Not Deleted -");
					}

				} else {
					JOptionPane.showMessageDialog(null, "Instructor Not Deleted : No E ID Entered Or Visible");
				}
			}
		});



		JButton btnFirst = new JButton("FIRST");
		btnFirst.setIcon(new ImageIcon(TeacherPanel.class.getResource("/icons/061-push-pin32.png")));
		btnFirst.setMargin(new Insets(2, 1, 2, 14));
		btnFirst.setIconTextGap(15);
		btnFirst.setHorizontalAlignment(SwingConstants.LEFT);
		btnFirst.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnFirst.setBackground(Color.WHITE);
		
		btnFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Window window;
				TeacherPanel.pos = 0;
				showItem(TeacherPanel.pos);

			}
		});



		JButton btnNext = new JButton("NEXT");
		btnNext.setIcon(new ImageIcon(TeacherPanel.class.getResource("/icons/007-right-arrow32.png")));
		btnNext.setMargin(new Insets(2, 1, 2, 14));
		btnNext.setIconTextGap(15);
		btnNext.setHorizontalAlignment(SwingConstants.LEFT);
		btnNext.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNext.setBackground(Color.WHITE);
		
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TeacherPanel.pos++;

				if (TeacherPanel.pos >= getInstrList().size()) {
					TeacherPanel.pos = getInstrList().size() - 1;
				}

				showItem(TeacherPanel.pos);
			}
		});



		JButton btnPrevious = new JButton("PREVIOUS");
		btnPrevious.setIcon(new ImageIcon(TeacherPanel.class.getResource("/icons/008-left-arrow32.png")));
		btnPrevious.setMargin(new Insets(2, 1, 2, 14));
		btnPrevious.setIconTextGap(15);
		btnPrevious.setHorizontalAlignment(SwingConstants.LEFT);
		btnPrevious.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnPrevious.setBackground(Color.WHITE);
		JButton btnLast = new JButton("LAST");

		btnPrevious.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				TeacherPanel.pos = TeacherPanel.pos - 1;

				if (TeacherPanel.pos <= 0) {
					TeacherPanel.pos = 0;
				}

				showItem(TeacherPanel.pos);
			}

		});


		btnLast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TeacherPanel.pos = getInstrList().size() - 1;
				showItem(TeacherPanel.pos);
			}

		});
		btnLast.setIcon(new ImageIcon(TeacherPanel.class.getResource("/icons/043-push-pin32.png")));
		btnLast.setMargin(new Insets(2, 1, 2, 14));
		btnLast.setIconTextGap(15);
		btnLast.setHorizontalAlignment(SwingConstants.LEFT);
		btnLast.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnLast.setBackground(Color.WHITE);

		JButton btnBack = new JButton("BACK");
		btnBack.setActionCommand("BACK");
		btnBack.addActionListener(this);

		txt_InID = new JTextField();
		txt_InID.setColumns(10);
		txt_InID.setVisible(false);

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING).addGroup(gl_contentPane
				.createSequentialGroup().addContainerGap().addComponent(btnBack).addGap(99)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(Instr_NAME, GroupLayout.PREFERRED_SIZE, 136, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(txtInName, GroupLayout.PREFERRED_SIZE, 227, GroupLayout.PREFERRED_SIZE))
						.addComponent(instructorTable, GroupLayout.PREFERRED_SIZE, 421, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(btnInsert, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)))
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
						.createSequentialGroup().addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(btnPrevious, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnNext, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnLast, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnFirst, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(117).addComponent(txt_InID,
								GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE)))
				.addGap(152)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(
								gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
												.addComponent(btnBack).addComponent(instructorTable,
														GroupLayout.PREFERRED_SIZE, 319, GroupLayout.PREFERRED_SIZE))
										.addGroup(gl_contentPane.createSequentialGroup()
												.addComponent(btnFirst, GroupLayout.PREFERRED_SIZE, 41,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(btnLast, GroupLayout.PREFERRED_SIZE, 41,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.UNRELATED)
												.addComponent(btnNext, GroupLayout.PREFERRED_SIZE, 41,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(btnPrevious,
														GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
						.addGap(31)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(Instr_NAME, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
								.addComponent(txtInName, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
						.addGap(93)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE).addComponent(btnInsert)
								.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 41,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(txt_InID, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE))
						.addGap(15)));

		dataTableShow = new JTable();
		dataTableShow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = dataTableShow.getSelectedRow();
				showItem(index);
			}
		});
		dataTableShow
				.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "INSTR_ID", "INSTRUCTOR_NAME" }));
		instructorTable.setViewportView(dataTableShow);

		contentPane.setLayout(gl_contentPane);

	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "BACK"){
			InstructorPanel ip = new InstructorPanel();
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			ip.setVisible(true);
			this.setVisible(false);
			ip.setLocationRelativeTo(null);
			this.dispose();
		}

	}
}