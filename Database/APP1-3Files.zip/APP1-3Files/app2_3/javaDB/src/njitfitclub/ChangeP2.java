/**
* ALLOW A PASSWORD CHANGE
*/

package njitfitclub;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JButton;

public class ChangeP2 extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private Connect conn = new Connect();
	private java.sql.Connection connect;

	private JPanel contentPane;
	private JTextField txtold;
	private JTextField txtnew;
	String str;

	/**
	 * Create the frame.
	 */
	public ChangeP2(String string) {
		str = string;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblEnterOldPassword = new JLabel("ENTER OLD PASSWORD: ");
		lblEnterOldPassword.setBounds(63, 56, 144, 37);
		contentPane.add(lblEnterOldPassword);

		JLabel lblEnterNewPassword = new JLabel("ENTER NEW PASSWORD");
		lblEnterNewPassword.setBounds(63, 104, 144, 37);
		contentPane.add(lblEnterNewPassword);

		txtold = new JTextField();
		txtold.setBounds(217, 56, 152, 28);
		contentPane.add(txtold);
		txtold.setColumns(10);

		txtnew = new JTextField();
		txtnew.setColumns(10);
		txtnew.setBounds(217, 108, 152, 28);
		contentPane.add(txtnew);

		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.setBounds(217, 165, 89, 23);
		btnUpdate.setActionCommand("UPDATE");
		btnUpdate.addActionListener(this);
		btnUpdate.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		contentPane.add(btnUpdate);

		JButton btnReturn = new JButton("RETURN");
		btnReturn.setBounds(0, 227, 89, 23);
		btnReturn.setActionCommand("RETURN");
		btnReturn.addActionListener(this);
		btnReturn.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		contentPane.add(btnReturn);
	}

	public void actionPerformed(ActionEvent e) {
		SelectPanelNonAdmin sp = new SelectPanelNonAdmin();
		if (e.getActionCommand() == "UPDATE") {
			connect = conn.getConnection();
			PreparedStatement ps;
			ResultSet rs;
			try {
				ps = connect.prepareStatement("SELECT USERNAME, PASSWORD FROM member WHERE PASSWORD = ?");
				ps.setString(1, txtold.getText());

				rs = ps.executeQuery(); // execute the query

				if (rs.next()) {

					ps = connect.prepareStatement("UPDATE member SET PASSWORD = ? WHERE USERNAME = ?");
					ps.setString(1, txtnew.getText());
					ps.setString(2, str);
					ps.executeUpdate();
					
					setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
					sp.setVisible(true);
					this.setVisible(false);
					sp.setLocationRelativeTo(null);
					this.dispose();
				} else {
					System.out.println("That Password is not on file");
				}

			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		if (e.getActionCommand() == "RETURN") {

			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

			sp.setVisible(true);
			this.setVisible(false);
			sp.setLocationRelativeTo(null);
			this.dispose();

		}
	}

}
