package njitfitclub;

public class Instructor {
	
	private int ASSIGN_ID;
	private int INSTR_ID;
	private String INSTRUCTOR_NAME;
	private int EX_ID;
	private String EX_NAME;
	
	public Instructor(int INSTR_ID, String INSTRUCTOR_NAME) {
		this.INSTR_ID = INSTR_ID;
		this.INSTRUCTOR_NAME = INSTRUCTOR_NAME;

	}

	public Instructor(int ASSIGN_ID, int INSTR_ID, String INSTRUCTOR_NAME,int EX_ID, String EX_NAME) {
		this.setASSIGN_ID(ASSIGN_ID);
		this.INSTR_ID = INSTR_ID;
		this.INSTRUCTOR_NAME = INSTRUCTOR_NAME;
		this.setEX_ID(EX_ID);
		this.setEX_NAME(EX_NAME);
	}

	public int getINSTR_ID() {
		return INSTR_ID;
	}

	public void setINSTR_ID(int iNSTR_ID) {
		INSTR_ID = iNSTR_ID;
	}

	public String getINSTRUCTOR_NAME() {
		return INSTRUCTOR_NAME;
	}

	public void setINSTRUCTOR_NAME(String iNSTRUCTOR_NAME) {
		INSTRUCTOR_NAME = iNSTRUCTOR_NAME;
	}



	public int getEX_ID() {
		return EX_ID;
	}

	public void setEX_ID(int eX_ID) {
		EX_ID = eX_ID;
	}

	public String getEX_NAME() {
		return EX_NAME;
	}

	public void setEX_NAME(String eX_NAME) {
		EX_NAME = eX_NAME;
	}

	public int getASSIGN_ID() {
		return ASSIGN_ID;
	}

	public void setASSIGN_ID(int aSSIGN_ID) {
		ASSIGN_ID = aSSIGN_ID;
	}

}
