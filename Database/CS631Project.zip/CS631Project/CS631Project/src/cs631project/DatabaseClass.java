/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs631project;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import static java.time.Instant.now;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Jianchao Wang
 */
public class DatabaseClass {

    Connection con=null;
    public DatabaseClass(){
    
    try{  
  
    con=DriverManager.getConnection(  
    "jdbc:mysql://localhost:3306/njitfitclub?autoReconnect=true&useSSL=false","username","pwd");  
  
    }
    catch(Exception e){ System.out.println(e);}

}
    public boolean deleteEmployee(String empname)
    {
        boolean flag=true;
        
        try {
            String sql = "delete from Instructor where INSTR_NAME=" + "'" +empname + "'";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(sql);

        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return flag;
    }
    public void updateEmployeeDetails(String oldname,String newname,String type,double salary,int hours)
    {
        try {
            int id=getInstructorId(oldname);
            String sql = "Update Instructor set INSTR_NAME=" + "'" +newname + "'" + "where INSTR_ID=" + id;
            Statement stmt = con.createStatement();
            String sql1="";
            Statement stmt1 = con.createStatement();
            stmt.executeUpdate(sql);
            
            
            if(type.equalsIgnoreCase("salary"))
            {
                sql1 = "Update Salary set salary=" + salary + " where INSTR_ID=" + id;
                stmt1.executeUpdate(sql1);
            }
            else
            {
                sql1 = "Update Wage set wage=" + salary + " where INSTR_ID=" + id;
                stmt1.executeUpdate(sql1);
                sql1 = "Update Wage set hours=" + hours + " where INSTR_ID=" + id;
                stmt1.executeUpdate(sql1);
            }
            
        } catch (SQLException ex) {
            
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public boolean insertEmployee(String name,String type,double salary,double wage,int hours)
    {
        boolean flag=true;
        try {
            
            String sql = "INSERT INTO Instructor(INSTR_TYPE,INSTR_NAME) values('" + type + "','" + name +"')";
            Statement stmt = con.createStatement();
            String sql1="";
            Statement stmt1 = con.createStatement();
            stmt.executeUpdate(sql);
             int id=getInstructorId(name);
            
            if(type.equalsIgnoreCase("school"))
            {
                sql1 = "INSERT INTO Salary(INSTR_ID,salary)" + "values(" + id + "," + salary +")";
            }
            else
            {
                sql1 = "INSERT INTO Wage(INSTR_ID,wage,hours) " + "values(" + id + "," + wage + "," + hours + ")";
            }
            stmt1.executeUpdate(sql1);
        } catch (SQLException ex) {
            flag=false;
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }

    public Connection getCon() {
        return con;
    }
    public double getEmployeeSalary(String type,int instructorId)
    {
        double salary=0.00;
        if(type.equalsIgnoreCase("school"))
        {
            try {
            String sql = "Select * from Salary where INSTR_ID=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, instructorId);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next())
                salary=rs.getDouble("salary");
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        else
        {
            try {
            String sql = "Select * from Wage where INSTR_ID=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, instructorId);
            ResultSet rs = ps.executeQuery();
            int hours=0;
            if(rs.next()){
                salary=rs.getDouble("wage");
                hours=rs.getInt("hours");
            }
            salary=(double)salary*hours;
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        double tax=(double)(18.0/100.0);
        tax=tax*salary;
        salary=salary-tax;
        return salary;
    }
    
    public double getOriginalSalary(String type,int instructorId)
    {
        double salary=0.00;
        if(type.equalsIgnoreCase("school"))
        {
            try {
            String sql = "Select * from Salary where INSTR_ID=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, instructorId);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next())
                salary=rs.getDouble("salary");
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        else
        {
            try {
            String sql = "Select * from Wage where INSTR_ID=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, instructorId);
            ResultSet rs = ps.executeQuery();
            int hours=0;
            if(rs.next()){
                salary=rs.getDouble("wage");
                hours=rs.getInt("hours");
            }
            salary=(double)salary*hours;
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        
        return salary;
    }
    
    public void addSalaryInfo(int instrid,String status,LocalDate d,double ftax,double statetax,double other)
    {
        try {
            java.sql.Date d1=java.sql.Date.valueOf( d );
            String sql = "INSERT INTO SalaryInfo " + "values(" + instrid + "," + "'" + status + "'" + "," + "'" +d1 + "'" + "," + other + "," + ftax + "," + statetax +")"; 
            Statement stmt = con.createStatement();
            stmt.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public boolean checkSalaryInfo(int instrid)
    {
        boolean flag=false;
        LocalDate now = LocalDate.now();
        try {
            
            java.sql.Date datesql1;
            String sql = "Select * from SalaryInfo where INSTR_ID=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, instrid);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                datesql1=rs.getDate("paidDate");
                LocalDate date2=datesql1.toLocalDate();
                Period diff = Period.between(now, date2);
                int days=diff.getDays();
                if(days<=30){
                    flag=true;
                    break;
                }
            }
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
    }
    
    public java.sql.Date convertJavaDateToSqlDate(java.util.Date date) {
    return new java.sql.Date(date.getTime());
    }
    public String getEmployeeType(String empname)
    {
        String emptype="";
        try {
            String sql = "Select * from Instructor where INSTR_NAME=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, empname);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next())
                emptype=rs.getString("INSTR_TYPE");
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return emptype;
    }
    public int getInstructorId(String empname)
    {
        int empid=-1;
        try {
            String sql = "Select * from Instructor where INSTR_NAME=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, empname);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next())
                empid=rs.getInt("INSTR_ID");
            
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return empid;
    }
    public boolean checkInstructor(String username)
 {
     boolean flag=false;
        try {
            //Statement stmt=con.createStatement();
            String sql = "Select * from Instructor where INSTR_NAME=? ";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next())
                flag=true;
            rs.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return flag;
 }
    
}
