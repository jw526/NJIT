package njitfitclub;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.BevelBorder;

public class SelectPanel extends JFrame implements ActionListener{

	private JPanel contentPane;
	private static SelectPanel frame;

	/**
	 * Create the frame.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new SelectPanel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	public SelectPanel() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 761, 424);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(30, 144, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnManEx = new JButton("Manage Exercises");
		btnManEx.setForeground(new Color(255, 255, 255));
		btnManEx.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManEx.setBackground(new Color(210, 105, 30));
		btnManEx.setBounds(89, 134, 140, 71);
		btnManEx.setActionCommand("EXERCISE");
		btnManEx.addActionListener(this);
		contentPane.add(btnManEx);

		JButton btnManCl = new JButton("Manage Classes");
		btnManCl.setForeground(new Color(255, 255, 255));
		btnManCl.setBackground(new Color(210, 105, 30));
		btnManCl.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManCl.setBounds(295, 134, 140, 71);
		btnManCl.setActionCommand("CLASS");
		btnManCl.addActionListener(this);
		contentPane.add(btnManCl);

		JButton btnManInst = new JButton("Manage Instructors");
		btnManInst.setForeground(new Color(255, 255, 255));
		btnManInst.setBackground(new Color(210, 105, 30));
		btnManInst.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManInst.setBounds(512, 134, 134, 71);
		btnManInst.setActionCommand("INSTRUCT");
		btnManInst.addActionListener(this);
		contentPane.add(btnManInst);
		
		JButton btnPrint = new JButton("Print Some Data");
		btnPrint.setBounds(193, 260, 334, 33);
		btnPrint.setActionCommand("PRINT");
		btnPrint.addActionListener(this);
		contentPane.add(btnPrint);
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "EXERCISE"){
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			ExercisePanel ep = new ExercisePanel();
			ep.setVisible(true); 
			this.setVisible(false);
			ep.setLocationRelativeTo(null);
			this.dispose();
			
		}
		if (e.getActionCommand() == "CLASS"){
			RegPanel rp = new RegPanel();
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			rp.setVisible(true);
			this.setVisible(false);
			rp.setLocationRelativeTo(null);
			this.dispose();
		}
		
		if (e.getActionCommand() == "INSTRUCT"){
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			InstructorPanel ip = new InstructorPanel();
			ip.setVisible(true); 
			this.setVisible(false);
			ip.setLocationRelativeTo(null);
			this.dispose();
			
		}
		
		if (e.getActionCommand() == "PRINT"){
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			PrintPanel pp = new PrintPanel();
			pp.setVisible(true); 
			this.setVisible(false);
			pp.setLocationRelativeTo(null);
			this.dispose();
			
		}

	}

}
