package njitfitclub;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;

public class SelectPanelNonAdmin extends JFrame implements ActionListener{

	private JPanel contentPane;
	private static SelectPanelNonAdmin frame;
	
	//Entry point to bypass login - for class demo 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new SelectPanelNonAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SelectPanelNonAdmin() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 761, 424);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(30, 144, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnManEx = new JButton("Register For Classes");
		btnManEx.setForeground(new Color(255, 255, 255));
		btnManEx.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManEx.setBackground(new Color(210, 105, 30));
		btnManEx.setBounds(172, 134, 140, 71);
		btnManEx.setActionCommand("REGISTER");
		btnManEx.addActionListener(this);
		contentPane.add(btnManEx);

		JButton btnManCl = new JButton("Change Password");
		btnManCl.setForeground(new Color(255, 255, 255));
		btnManCl.setBackground(new Color(210, 105, 30));
		btnManCl.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnManCl.setBounds(419, 134, 140, 71);
		btnManCl.setActionCommand("CHANGE");
		btnManCl.addActionListener(this);
		contentPane.add(btnManCl);
		
		JLabel lblHello = new JLabel("Hello   " + LogIn.holdUname + " !");
		lblHello.setForeground(Color.WHITE);
		lblHello.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		lblHello.setBounds(286, 11, 156, 34);
		contentPane.add(lblHello);


	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand() == "REGISTER"){
			RegForClass rfc = null;
			try {
				rfc = new RegForClass();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			rfc.setVisible(true);
			this.setVisible(false);
			rfc.setLocationRelativeTo(null);
			this.dispose();
		}
		if (e.getActionCommand() == "CHANGE"){
			ChangePword cp = new ChangePword();
			setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			cp.setVisible(true);
			this.setVisible(false);
			cp.setLocationRelativeTo(null);
			this.dispose();
		}

	}

}



