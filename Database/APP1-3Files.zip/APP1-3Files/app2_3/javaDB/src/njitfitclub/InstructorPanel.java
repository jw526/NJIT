package njitfitclub;

// make TWO COMMANDS - INSERT INSTR ID & INSERT CLASSES

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class InstructorPanel extends JFrame implements ActionListener{
	Connect conn = new Connect();
	java.sql.Connection connect;

		private static final long serialVersionUID = -1858692165751812300L;

		private static int pos = 0;

		public static int getPos() {
			return pos;
		}

		private JPanel contentPane;
		private JTextField txt_Instr_ID;
		private JTextField txt_Instr_NAME;
		private static InstructorPanel frame;

		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						frame = new InstructorPanel();
						frame.setVisible(true);

					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the frame.
		 */
		public InstructorPanel() {
			initComponents();
			displayData();
		}

		/**
		 * Check Input Field
		 */
		public boolean checkInputs() {
			if (txt_Instr_ID.getText() == null ) {
				return false;
			} else {
				try {
					txt_Instr_ID.getText();
					return true;
				} catch (Exception ex) {
					return false;
				}
			}

		}

		/**
		 * Display Data In JTable - Fill ArrayList With The Data
		 * 
		 */
		public ArrayList<Instructor> getInstrList1() {
			ArrayList<Instructor> instrList = new ArrayList<Instructor>();
			connect = conn.getConnection();
			String query = "SELECT T.ASSIGN_ID, T.INSTR_ID, I.INSTRUCTOR_NAME, T.EX_ID, E.EX_NAME "
					+ "FROM instructor I, exercises E, teach T "
					+ "WHERE T.INSTR_ID = I.INSTR_ID AND T.EX_ID = E.EX_ID"
					+ " ORDER BY T.INSTR_ID";

			Statement st;
			ResultSet rs;

			try {
				st = connect.createStatement();
				rs = st.executeQuery(query);
				Instructor instr;
				while (rs.next()) {
					instr = new Instructor(rs.getInt("ASSIGN_ID"), rs.getInt("INSTR_ID"), rs.getString("INSTRUCTOR_NAME"), rs.getInt("EX_ID"), rs.getString("EX_NAME"));
					instrList.add(instr);
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
			return instrList;

		}

		/**
		 * Display Data In JTable - Populate the JTable
		 * 
		 */

		public void displayData() {
			ArrayList<Instructor> list = getInstrList1();
			DefaultTableModel model = (DefaultTableModel) dataTable.getModel();
			
			connect = conn.getConnection();
	
			model.setRowCount(0);// clearJTableContent
			Object[] row = new Object[5];
			for (int i = 0; i < list.size(); i++) {
				row[0] = list.get(i).getASSIGN_ID() ;
				row[1] = list.get(i).getINSTR_ID();
				row[2] = list.get(i).getINSTRUCTOR_NAME();
				row[3] = list.get(i).getEX_ID();
				row[4] = list.get(i).getEX_NAME();

				model.addRow(row);
			}

		}

		public void showItem(int Index) {
			txt_assign.setText(Integer.toString(getInstrList1().get(Index).getASSIGN_ID()));
			txt_Instr_ID.setText(Integer.toString(getInstrList1().get(Index).getINSTR_ID()));
			txt_Instr_NAME.setText(getInstrList1().get(Index).getINSTRUCTOR_NAME());
			txt_EX_ID.setText(Integer.toString(getInstrList1().get(Index).getEX_ID()));
			txt_EX_NAME.setText(getInstrList1().get(Index).getEX_NAME());
		}

		
		/**
		 * Initial the Main Window & its components
		 */

		private JTable dataTable;
		private JTextField txt_EX_ID;
		private JTextField txt_EX_NAME;
		private JTextField txt_assign;

		public void initComponents() {

			setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
			setBounds(100, 100, 932, 593);
			setIconImage(Toolkit.getDefaultToolkit().getImage(Icon.class.getResource("/lib/largeowl.png")));
			contentPane = new JPanel();
			contentPane.setBackground(new Color(135, 206, 235));
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);

			JLabel Instr_IDLabel = new JLabel("INSTR_ID:");
			Instr_IDLabel.setHorizontalAlignment(SwingConstants.LEFT);
			Instr_IDLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));

			JLabel Instr_NameLabel = new JLabel("Instr Name:");
			Instr_NameLabel.setHorizontalAlignment(SwingConstants.LEFT);
			Instr_NameLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));

			JLabel teachesLabel = new JLabel("EX_ID");
			teachesLabel.setHorizontalAlignment(SwingConstants.LEFT);
			teachesLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));

			JScrollPane instrTable = new JScrollPane();

			// BUTTONS
			JButton btnInsert = new JButton("INSERT");
			btnInsert.setBackground(Color.WHITE);
			btnInsert.setMargin(new Insets(2, 5, 2, 14));
			btnInsert.setHorizontalAlignment(SwingConstants.LEFT);
			btnInsert.setIconTextGap(15);
			btnInsert.setIcon(new ImageIcon(InstructorPanel.class.getResource("/icons/addButton32.png")));
			btnInsert.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnInsert.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					System.out.println("yes");

					try {
						connect = conn.getConnection();

						String query = " insert into teach (INSTR_ID, EX_ID)" + " values(?, ?)";
						PreparedStatement ps = connect.prepareStatement(query);
						ps.setString(1, txt_Instr_ID.getText());
						ps.setString(2, txt_EX_ID.getText());

						JOptionPane.showMessageDialog(null, "data entered");

						ps.executeUpdate();

						displayData();

					} catch (SQLException ex) {

						JOptionPane.showMessageDialog(null, ex.getMessage());
					}

				}
			});


			JButton btnUpdate = new JButton("UPDATE");
			btnUpdate.setIcon(new ImageIcon(InstructorPanel.class.getResource("/icons/026-bar-chart32.png")));
			btnUpdate.setActionCommand("");
			btnUpdate.setMargin(new Insets(2, 1, 2, 14));
			btnUpdate.setIconTextGap(15);
			btnUpdate.setHorizontalAlignment(SwingConstants.LEFT);
			btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnUpdate.setBackground(Color.WHITE);
			btnUpdate.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					//if (checkInputs() && txt_Instr_ID.getText() != null) 
					//{
						String UpdateQuery = null;
						PreparedStatement ps = null;
						connect = conn.getConnection();

						// update without and image

						UpdateQuery = "UPDATE teach SET EX_ID=? WHERE ASSIGN_ID=? ";

						try {
							ps = connect.prepareStatement(UpdateQuery);

							ps.setString(1, txt_EX_ID.getText());
							ps.setString(2, txt_assign.getText());
							ps.executeUpdate();
							JOptionPane.showMessageDialog(null, "Assignment Updated");
							displayData();

						} catch (SQLException ex) {
							ex.printStackTrace();
						}
				//	}
				}
			});



			JButton btnDelete = new JButton("DELETE");
			btnDelete.setIcon(new ImageIcon(InstructorPanel.class.getResource("/icons/deleteButton32.png")));
			btnDelete.setMargin(new Insets(2, 5, 2, 14));
			btnDelete.setIconTextGap(15);
			btnDelete.setHorizontalAlignment(SwingConstants.LEFT);
			btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnDelete.setBackground(Color.WHITE);
			btnDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {

					if (!txt_Instr_ID.getText().equals("")) {
						System.out.println(txt_Instr_ID.getText());
						try {
							connect = conn.getConnection();
							String deleteQuery = "DELETE FROM teach WHERE ASSIGN_ID = ?";
							PreparedStatement ps = connect.prepareStatement(deleteQuery);
							ps.setString(1, txt_assign.getText());
							ps.executeUpdate();
							JOptionPane.showMessageDialog(null, "Assignment Deleted");
							displayData();

						} catch (SQLException e) {
							e.printStackTrace();
							JOptionPane.showMessageDialog(null, "Assignment Not Deleted -");
						}

					} else {
						JOptionPane.showMessageDialog(null, "Instructor Not Deleted : No INSTR ID Entered Or Visible");
					}
				}
			});



			JButton btnFirst = new JButton("FIRST");
			btnFirst.setIcon(new ImageIcon(InstructorPanel.class.getResource("/icons/061-push-pin32.png")));
			btnFirst.setMargin(new Insets(2, 1, 2, 14));
			btnFirst.setIconTextGap(15);
			btnFirst.setHorizontalAlignment(SwingConstants.LEFT);
			btnFirst.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnFirst.setBackground(Color.WHITE);
			btnFirst.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					// Window window;
					InstructorPanel.pos = 0;
					showItem(InstructorPanel.pos);
					
				}
			});



			JButton btnNext = new JButton("NEXT");
			btnNext.setIcon(new ImageIcon(InstructorPanel.class.getResource("/icons/007-right-arrow32.png")));
			btnNext.setMargin(new Insets(2, 1, 2, 14));
			btnNext.setIconTextGap(15);
			btnNext.setHorizontalAlignment(SwingConstants.LEFT);
			btnNext.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnNext.setBackground(Color.WHITE);
			btnNext.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					InstructorPanel.pos++;

					if (InstructorPanel.pos >= getInstrList1().size()) {
						InstructorPanel.pos = getInstrList1().size() - 1;
					}

					showItem(InstructorPanel.pos);
				}
			});

			JButton btnPrevious = new JButton("PREVIOUS");
			btnPrevious.setIcon(new ImageIcon(InstructorPanel.class.getResource("/icons/008-left-arrow32.png")));
			btnPrevious.setMargin(new Insets(2, 1, 2, 14));
			btnPrevious.setIconTextGap(15);
			btnPrevious.setHorizontalAlignment(SwingConstants.LEFT);
			btnPrevious.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnPrevious.setBackground(Color.WHITE);
			btnPrevious.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					InstructorPanel.pos = InstructorPanel.pos - 1;
					if (InstructorPanel.pos <= 0) {
						InstructorPanel.pos = 0;}
					showItem(InstructorPanel.pos);
				}

			});
			
			JButton btnLast = new JButton("LAST");
			btnLast.setIcon(new ImageIcon(InstructorPanel.class.getResource("/icons/043-push-pin32.png")));
			btnLast.setMargin(new Insets(2, 1, 2, 14));
			btnLast.setIconTextGap(15);
			btnLast.setHorizontalAlignment(SwingConstants.LEFT);
			btnLast.setFont(new Font("Tahoma", Font.PLAIN, 14));
			btnLast.setBackground(Color.WHITE);
			btnLast.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					InstructorPanel.pos = getInstrList1().size() - 1;
					showItem(InstructorPanel.pos);
				}

			});

			
			JButton btnBack = new JButton("BACK");
			btnBack.setActionCommand("BACK");
			btnBack.addActionListener(this);
			
			JButton btnAddremoveInstructor = new JButton("Add/Remove Instructor");
			btnAddremoveInstructor.setActionCommand("ADD_REMOVE");
			btnAddremoveInstructor.addActionListener(this);
			
			txt_Instr_ID = new JTextField();
			txt_Instr_ID.setDisabledTextColor(Color.BLUE);
			txt_Instr_ID.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txt_Instr_ID.setColumns(10);

			txt_Instr_NAME = new JTextField();
			txt_Instr_NAME.setDisabledTextColor(Color.DARK_GRAY);
			txt_Instr_NAME.setSelectionColor(Color.DARK_GRAY);
			txt_Instr_NAME.setText("");
			txt_Instr_NAME.setSelectionStart(10);
			txt_Instr_NAME.setSelectionEnd(10);
			txt_Instr_NAME.setEnabled(false);
			txt_Instr_NAME.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
			txt_Instr_NAME.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txt_Instr_NAME.setColumns(10);

			
			txt_EX_ID = new JTextField();
			txt_EX_ID.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txt_EX_ID.setColumns(10);
			
			txt_EX_NAME = new JTextField();
			txt_EX_NAME.setDisabledTextColor(Color.DARK_GRAY);
			txt_EX_NAME.setSelectionColor(Color.DARK_GRAY);
			txt_EX_NAME.setFont(new Font("Tahoma", Font.PLAIN, 14));
			txt_EX_NAME.setColumns(10);
			txt_EX_NAME.setEnabled(false);
			
			JLabel lblEX = new JLabel("Exercise:");
			lblEX.setHorizontalAlignment(SwingConstants.LEFT);
			lblEX.setFont(new Font("Tahoma", Font.PLAIN, 18));
			
			JLabel lblAssign = new JLabel("ASSIGN INSTRUCTOR TO CLASS");
			lblAssign.setFont(new Font("Tahoma", Font.PLAIN, 14));
			
			txt_assign = new JTextField();
			txt_assign.setColumns(10);
			txt_assign.setVisible(false);
		
			/* 
			 * code generator from window builder - GROUP_LAYOUT
			 */

			GroupLayout gl_contentPane = new GroupLayout(contentPane);
			gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.TRAILING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
							.addGroup(gl_contentPane.createSequentialGroup()
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(btnInsert, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE))
									.addComponent(btnAddremoveInstructor))
								.addGap(260)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(btnLast, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(btnFirst, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
										.addComponent(btnNext, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addComponent(btnPrevious))
								.addGap(55))
							.addGroup(gl_contentPane.createSequentialGroup()
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addGap(10)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
											.addComponent(Instr_NameLabel, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
											.addComponent(Instr_IDLabel, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
											.addComponent(teachesLabel, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
											.addComponent(lblEX, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)))
									.addComponent(btnBack))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addComponent(lblAssign)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(txt_Instr_NAME)
										.addComponent(txt_Instr_ID, GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
									.addComponent(txt_EX_NAME, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE)
									.addComponent(txt_EX_ID, GroupLayout.PREFERRED_SIZE, 200, GroupLayout.PREFERRED_SIZE))
								.addGap(124)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
									.addComponent(instrTable, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
									.addComponent(txt_assign, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE))
								.addGap(44))))
			);
			gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
					.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addGroup(gl_contentPane.createSequentialGroup()
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(btnBack)
									.addComponent(lblAssign))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addGap(28)
										.addComponent(Instr_IDLabel, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
									.addGroup(gl_contentPane.createSequentialGroup()
										.addGap(42)
										.addComponent(txt_Instr_ID, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)))
								.addGap(18)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(Instr_NameLabel, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
									.addComponent(txt_Instr_NAME, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(txt_EX_ID, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
									.addComponent(teachesLabel, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
								.addGap(16)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
									.addComponent(txt_EX_NAME, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
									.addComponent(lblEX, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)))
							.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(instrTable, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(txt_assign, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)))
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
							.addGroup(gl_contentPane.createSequentialGroup()
								.addGap(50)
								.addComponent(btnFirst, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
								.addGap(18)
								.addComponent(btnLast)
								.addGap(32)
								.addComponent(btnNext)
								.addPreferredGap(ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
								.addComponent(btnPrevious, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
								.addContainerGap())
							.addGroup(gl_contentPane.createSequentialGroup()
								.addGap(42)
								.addComponent(btnAddremoveInstructor)
								.addPreferredGap(ComponentPlacement.RELATED, 133, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
									.addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
									.addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
									.addComponent(btnInsert))
								.addGap(36))))
			);

			dataTable = new JTable();
			dataTable.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					int index = dataTable.getSelectedRow();
					showItem(index);
				}
			});
			dataTable
					.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "ID", "INSTR_ID", "INSTRUCTOR_NAME", "EX_ID", "EXERCISE_TAUGHT"}));
			dataTable.getColumnModel().getColumn(0).setPreferredWidth(30);
			dataTable.getColumnModel().getColumn(1).setPreferredWidth(30);
			dataTable.getColumnModel().getColumn(2).setPreferredWidth(150);
			dataTable.getColumnModel().getColumn(3).setPreferredWidth(30);
			dataTable.getColumnModel().getColumn(4).setPreferredWidth(150);
			instrTable.setViewportView(dataTable);

			contentPane.setLayout(gl_contentPane);

		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getActionCommand() == "ADD_REMOVE"){
				setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
				TeacherPanel tp = new TeacherPanel();
				tp.setVisible(true);
				this.setVisible(false);
				tp.setLocationRelativeTo(null);
				this.dispose();
			}
			if (e.getActionCommand() == "BACK"){
				SelectPanel sp = new SelectPanel();
				setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
				sp.setVisible(true);
				this.setVisible(false);
				sp.setLocationRelativeTo(null);
				this.dispose();
			}

		}
	}
