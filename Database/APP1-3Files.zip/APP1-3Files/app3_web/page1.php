<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
		document.getElementById("reg").onclick = display;
		
        function display() {
				
                document.getElementById("div1").style.display = 'block';
			
        }
</script>
<style>
table, th, td {
    border: 1px solid black;
	margin-left:350px;
    text-align:center;
}
.error {color: #FF0000;}

</style>

</head>
<body bgcolor="#E6E6FA">

<?php

$servername = "localhost";
$username = "";
$password = "";
$dbname = "njitfitclub";
// define variables and set to empty values
$fnameErr = $lnameErr = $addressErr = $membershipErr =  "";
$fname = $lname = $address = $membership =  "";
$idError="";
$capacity=0;
$flag=true;
$id=0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["fname"])) {
    $fnameErr = "First Name is required";
	$flag=false;
  } else {
    $fname = test_input($_POST["fname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$fname)) {
      $fnameErr = "Only letters and white space allowed";
		$flag=false;
    }
  }
  if (empty($_POST["lname"])) {
    $lnameErr = "Last Name is required";
	$flag=false;
  } else {
    $lname = test_input($_POST["lname"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z ]*$/",$lname)) {
		$flag=false;
      $lnameErr = "Only letters and white space allowed"; 
    }
  }
  if (empty($_POST["address"])) {
    $addressErr = "Address is required";
	$flag=false;
  } else {
    $address = test_input($_POST["address"]);
    
  }
    
  if (empty($_POST["membership"])) {
    $membershipErr = "Membership type is required";
	$flag=false;
  } else {
    $membership = test_input($_POST["membership"]);
  }
  
  if (empty($_POST["classid"])) {
    $idError = "Class id is required";
	$flag=false;
  } else {
    $id = test_input($_POST["classid"]);
  }
 
  
  $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
  $sql = "SELECT CAPACITY from Class where CLASS_ID=".$id."";
$result = $conn->query($sql);
if($flag==true){
if ($result) { 
	$rowcount=mysqli_num_rows($result);
	if($rowcount>0){
		$row=$result->fetch_assoc();
		$memberid=0;
		$capacity= $row["CAPACITY"];
		if($capacity>0){
		$ddate=date("Y-m-d");
		$sql = "INSERT INTO Member (FIRST_NAME,LAST_NAME,ADDRESS,REG_DATE,TYPE_NAME)
VALUES('". $fname ."','". $lname ."','". $address ."',CAST('". $ddate ."' AS DATE),'". $membership ."')";
		
		if(mysqli_query($conn, $sql)){
			$capacity=$capacity-1;
				
				$sql = "SELECT MEM_ID FROM member order by MEM_ID desc LIMIT 1";
				$result = $conn->query($sql);
				$row=$result->fetch_assoc();
				$memberid=$row["MEM_ID"];
				
				$sql = "INSERT INTO exercise_reg (MEM_ID,CLASS_ID) values ($memberid,$id)";
				if(mysqli_query($conn, $sql)){
					echo "Registered successfully.";
					$sql = "UPDATE exerciseclass SET CAPACITY=$capacity WHERE CLASS_ID=".$id."";
					if ($conn->query($sql) === TRUE) {
						
					} else {
					echo "Error updating record: " . $conn->error;
					}
				}
				else{
					echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
				}		
		} else{
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
		}
	}
	else
	{
		echo "This class is full. Please select another class";
	}
	}
 else {
    echo "Please enter correct class id";
}
}
}
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>


<form id="form1" method="POST"  >
<h2 align="center">Welcome to Fitness Club</h2>
<br>
<h2 align="center" style="color:red">Classes Information</h2>
<?php
$servername = "localhost";
$username = "";
$password = "";
$dbname = "njitfitclub";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT CLASS_ID,INSTR_NAME,EX_NAME,RM_NUM,DATE,TIME,DURATION FROM ExerciseClass inner join Instructor on Instructor.INSTR_ID=ExerciseClass.INSTR_ID inner join Exercises on Exercises.EX_ID=ExerciseClass.EX_ID";
$result = $conn->query($sql);

if ($result) {
    echo "<table ><tr><th>CLASS_ID</th><th>Instructor Name</th><th>Exercise Name</th><th>Room Number</th><th>Date</th><th>Time</th><th>Duration</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["CLASS_ID"]. "</td><td>" . $row["INSTR_NAME"]. "</td><td>" . $row["EX_NAME"]. "</td><td>" . $row["RM_NUM"]. "</td><td>" . $row["DATE"]. "</td><td>" . $row["TIME"]. "</td><td>" . $row["DURATION"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "No classes available right now";
}


?>
<br>

<div id="div1" align="center" >
First Name: <input type="text" name="fname" value="<?php if (isset($_POST['fname'])) echo $_POST['fname']; ?>"   /><span class="error">* <?php echo $fnameErr;?></span><br><br>Last name: <input type="text" name="lname" value="<?php if (isset($_POST['lname'])) echo $_POST['lname']; ?>"    /><span class="error">* <?php echo $lnameErr;?></span><br><br>
Address: <input type="text" name="address" value="<?php if (isset($_POST['address'])) echo $_POST['address']; ?>"    /><span class="error">* <?php echo $addressErr;?></span><br><br>
Membership Type: 
  <input type="radio" name="membership" <?php if (isset($gender) && $gender=="regular") echo "checked";?> value="Student">Student<span class="error">* <?php echo $membershipErr;?></span><br>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="membership" <?php if (isset($gender) && $gender=="premium") echo "checked";?> value="VIP">VIP<br>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="membership" <?php if (isset($gender) && $gender=="premium") echo "checked";?> value="Senior">Senior<br>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="membership" <?php if (isset($gender) && $gender=="premium") echo "checked";?> value="Ordniary">Ordniary<br>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="membership" <?php if (isset($gender) && $gender=="premium") echo "checked";?> value="Family">Family<br>
  
  <br><br>
Enter class id here: <input type="number" name="classid" value="<?php if (isset($_POST['classid'])) echo $_POST['classid']; ?>"    /><span class="error">* <?php echo $idError;?></span><br><br>
<input type="submit" name="submitbtn" value="Register me!"  />
<br>

</div>
<br>


</form>
</body>
</html>